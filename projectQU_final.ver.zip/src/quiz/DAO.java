package quiz;

import java.io.IOException;
import java.sql.*;
import java.util.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

import org.json.simple.*;

//  DataBase Access Object
public class DAO {
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private Statement stmt = null;
	private ResultSet rs = null;
	private static DAO dao = new DAO();
	
	private DAO() {
		
	}
	public static DAO getInstance() {
		return dao;
	}
	
	public Connection getMysql() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/quizdb?useUnicode=true&characterEncoding=utf-8";
		String user = "quiz1";
		String password = "quiz1";
			
		Connection conn2 = DriverManager.getConnection(url, user, password);
		return conn2;
	}
	
	public boolean closeMysql() {
		boolean result = false;
		
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(stmt != null) stmt.close();
			if(conn != null) conn.close();
			
			result = true;
		}
		catch (SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch (Exception e) {
			e.getStackTrace();
			return false;
		}
		
		return result;
	}
	
	public boolean login(String id, String pw) {
		boolean result = false;
		try {
			conn = getMysql();
			String sql = "SELECT * FROM users WHERE id=? and pw=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rs = pstmt.executeQuery(); 
			if(rs.next())
				result = true;
		}
		catch (SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch (Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
		
		return result;
	} 
	
	public boolean id_duplicate_check(String id) {
		boolean result = false;
		
		Connection conn2 = null; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		
		try {
			int num = 0;
			conn2 = getMysql();
			String sql = "SELECT COUNT(*) as num FROM users WHERE id=?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setString(1, id);
			
			rs2 = pstmt2.executeQuery(); 
			if(rs2.next())
				num = rs2.getInt("num");
			result = (num > 0) ? true: false;
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
		}
		catch (SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch (Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			// closeMysql();
		}
		
		return result;
	}
	
	public boolean create(String id, String pw) {
		boolean result = false;
		try {
			conn = getMysql();
			String sql = "SELECT * FROM users WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			rs = pstmt.executeQuery(); 
			if(rs.next()) {
				System.out.println("�̹� ���� ���̵� �����մϴ�~!");
				result = false;
			}
			else {
				pstmt.close();
				sql = "INSERT INTO users(logged_in, id, pw, grade, exps, points, banned_start_day, banned_end_day)" + 
					" VALUES (0, ?, ?, 0, 0, 0, NULL, NULL)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, id);
				pstmt.setString(2, pw);
				pstmt.executeUpdate();
				result = true;
			}
		}
		catch (SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch (Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean QueAnsCreate(String[] questions, String answer, byte levels, byte types) {
		int a_num = 0;
		boolean result = false;
		
		try {
			conn = getMysql();
			
			String q_sql = "SELECT COUNT(*) as N FROM default_questions WHERE ";
			//pstmt = conn.prepareStatement(q_sql);
			q_sql = q_sql + " question = ? ";
			for(int i = 1; i < questions.length; i++) {
				q_sql = q_sql + " or question = ? ";
			} 
			pstmt = conn.prepareStatement(q_sql);
			System.out.println(q_sql);
			for(int i = 0; i < questions.length; i++) {
				pstmt.setString(i + 1, questions[i]);
			}
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getInt("N") != 0) 
					return false;
			}
			rs.close(); pstmt.close();
			
			String ans_sql = "SELECT COUNT(*) as N FROM default_answers WHERE answer = ?";
			pstmt = conn.prepareStatement(ans_sql);
			pstmt.setString(1, answer);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getInt("N") != 0) 
					return false;
			}
			rs.close(); pstmt.close();
			
			ans_sql = "INSERT INTO default_answers(answer, levels, types)" + 
					" VALUES (?, ?, ?)";
			pstmt = conn.prepareStatement(ans_sql);
			pstmt.setString(1, answer);
			pstmt.setByte(2, levels);
			pstmt.setByte(3, types);
			pstmt.executeUpdate();
			pstmt.close();
			
			Statement stmt = conn.createStatement();
			ans_sql ="SELECT IFNULL(max(a_num), 0) as a_num FROM default_answers";
			rs = stmt.executeQuery(ans_sql);
			if(rs.next())
				a_num = rs.getInt("a_num");
			rs.close();
			
			for(int i = 0; i < questions.length; i++) {
				q_sql = "INSERT INTO default_questions(question, a_num, levels, types)"
						+ " VALUES (?, ?, ?, ?)";
				pstmt = conn.prepareStatement(q_sql);
				pstmt.setString(1, questions[i]);
				pstmt.setInt(2, a_num);
				pstmt.setByte(3, levels);
				pstmt.setByte(4, types);
				pstmt.executeUpdate();
				pstmt.close();
			}
			
			result = true;
		}
		catch(SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch(Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean QueCreate(String[] questions, int a_num, byte levels, byte types) {
		boolean result = false;
		
		try {
			conn = getMysql();
			String q_sql = "SELECT COUNT(*) as N FROM default_questions WHERE ";
			//pstmt = conn.prepareStatement(q_sql);
			q_sql = q_sql + " question = ? ";
			for(int i = 1; i < questions.length; i++) {
				q_sql = q_sql + " or question = ? ";
			} 
			pstmt = conn.prepareStatement(q_sql);
			System.out.println(q_sql);
			for(int i = 0; i < questions.length; i++) {
				pstmt.setString(i + 1, questions[i]);
			}
			rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getInt("N") != 0) 
					return false;
			}
			rs.close(); pstmt.close();
			
			
			for(int i = 0; i < questions.length; i++) {
				q_sql = "INSERT INTO default_questions(question, a_num, levels, types)"
						+ " VALUES (?, ?, ?, ?)";
				pstmt = conn.prepareStatement(q_sql);
				pstmt.setString(1, questions[i]);
				pstmt.setInt(2, a_num);
				pstmt.setByte(3, levels);
				pstmt.setByte(4, types);
				pstmt.executeUpdate();
				pstmt.close();
			}
			
			result = true;
		}
		catch(SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch(Exception e) {		
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
		
		return result;
	}
	
	public int[] QuesAnsNum() {
		int[] num = new int[2]; // new �����ڴ� �ڵ� �ʱ�ȭ��
		// num[0] : ��ü question ��
		// num[1] : ��ü answer ��
		
		try {
			conn = getMysql();
			stmt = conn.createStatement();
			String sql = "SELECT COUNT(*) AS q_nums FROM default_questions";
			rs = stmt.executeQuery(sql);
			if(rs.next())
				num[0] = rs.getInt("q_nums");
			rs.close();
			stmt.close();
			
			conn = getMysql();
			stmt = conn.createStatement();
			String sql2 = "SELECT COUNT(*) AS a_nums FROM default_answers";
			rs = stmt.executeQuery(sql2);
			if(rs.next())
				num[1] = rs.getInt("a_nums");
			rs.close();
			stmt.close();
			
		} catch (SQLException e) {
			e.printStackTrace();
			num[0]=0; num[1]=0;
			return num;
		} catch (Exception e) {
			e.printStackTrace();
			num[0]=0; num[1]=0;
			return num;
		} finally {
			closeMysql();
		}
		
		return num;
	}
	
	public String[] SearchQ_by_num(int q_num) {
		String[] Q_A = new String[5]; // new �����ڴ� �ڵ� �ʱ�ȭ��
		// Q_A[0] : question
		// Q_A[1] : answer
		// Q_A[2] : a_num (���� �� hidden �Է¿� �ʿ�!)
		// Q_A[3] : levels
		// Q_A[4] : types
		int a_num = 0; // question�� ���� answer ��ȣ(a_num)
		
		try {
			conn = getMysql();
			String sql = "SELECT question, a_num, levels, types FROM default_questions WHERE q_num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, q_num);
			
			rs = pstmt.executeQuery(); 
			if(rs.next()) {
				Q_A[0] = rs.getString("question");
				a_num = rs.getInt("a_num");
				Q_A[2] = Integer.toString(a_num);
				Q_A[3] = Byte.toString(rs.getByte("levels"));
				Q_A[4] = Byte.toString(rs.getByte("types"));
			}
			rs.close();
			pstmt.close();
			
			String sql2 = "SELECT answer FROM default_answers WHERE a_num = ?";
			pstmt = conn.prepareStatement(sql2);
			pstmt.setInt(1, a_num);
			
			rs = pstmt.executeQuery();
			if(rs.next()) 
				Q_A[1] = rs.getString("answer");
			rs.close();
			pstmt.close();
		} catch(SQLException e) {
			e.getStackTrace();
			Q_A[0] = ""; Q_A[1] = ""; Q_A[2] = ""; Q_A[3] = ""; Q_A[4] = ""; Q_A[5] = "";
			return Q_A;
		} catch(Exception e) {
			e.getStackTrace();
			Q_A[0] = ""; Q_A[1] = ""; Q_A[2] = ""; Q_A[3] = ""; Q_A[4] = ""; Q_A[5] = "";
			return Q_A;
		} finally {
			closeMysql();
		}
		
		return Q_A;
	}
	
	public String SearchQ_by_like(String q_like) {
		String q_nums = "";
		
		try {
			conn = getMysql(); // " like '%" + in_search_value + "%'";
			stmt = conn.createStatement();
			String sql = "SELECT q_num FROM default_questions WHERE question like '%" + q_like + "%' ORDER BY q_num ASC;";
			rs = stmt.executeQuery(sql);
			while(rs.next())
				q_nums = q_nums + rs.getString("q_num") + " ,";
			q_nums = q_nums + "... END";
			
			rs.close();
			stmt.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			q_nums = "";
			return q_nums;
		} catch(Exception e) {
			e.printStackTrace();
			q_nums = "";
			return q_nums;
		} finally {
			closeMysql();
		}
		
		return q_nums;
	}

	public boolean UpdateQuestion(String question, int q_num) {
		boolean result = false;
	
		try {
			conn = getMysql();
		
			String q_sql = "UPDATE default_questions SET question=? WHERE q_num=?";
				pstmt = conn.prepareStatement(q_sql);
				pstmt.setString(1, question);
				pstmt.setInt(2, q_num);
				pstmt.executeUpdate();
				pstmt.close();
				result = true;
		}
		catch(SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch(Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
	
		return result;
	}
	
	public boolean UpdateAnswer(String answer, int a_num) {
		boolean result = false;
	
		try {
			conn = getMysql();
		
			String a_sql = "UPDATE default_answers SET answer=? WHERE a_num=?";
				pstmt = conn.prepareStatement(a_sql);
				pstmt.setString(1, answer);
				pstmt.setInt(2, a_num);
				pstmt.executeUpdate();
				pstmt.close();
		
				result = true;
		}
		catch(SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch(Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
	
		return result;
	}
	
	public boolean UpdateLevelType(int q_num, int a_num, byte levels, byte types) {
		boolean result = false;
	
		try {
			conn = getMysql();
		
			String q_sql = "UPDATE default_questions SET levels=?, types=? WHERE q_num=?";
			pstmt = conn.prepareStatement(q_sql);
			pstmt.setByte(1, levels);
			pstmt.setByte(2, types);
			pstmt.setInt(3, q_num);
			pstmt.executeUpdate();
			pstmt.close();
				
			String a_sql = "UPDATE default_answers SET levels=?, types=? WHERE a_num=?";
			pstmt = conn.prepareStatement(a_sql);
			pstmt.setByte(1, levels);
			pstmt.setByte(2, types);
			pstmt.setInt(3, a_num);
			pstmt.executeUpdate();
			pstmt.close();
				
			result = true;
		}	
		catch(SQLException e) {
			e.getStackTrace();
			return false;
		}
		catch(Exception e) {
			e.getStackTrace();
			return false;
		}
		finally {
			closeMysql();
		}
	
		return result;
	}
	
	public String GetQuestion(int q_num) {
		String question;
		
		try {
			conn = getMysql();
			
			String sql = "SELECT question FROM default_questions WHERE q_num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, q_num);
			rs = pstmt.executeQuery();
			
			if(rs.next())
				question = rs.getString("question");
			else
				question = null;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return question;
	}
	
	public String GetAnswer(int a_num) {
		String answer;
		
		try {
			conn = getMysql();
			
			String sql = "SELECT answer FROM default_answers WHERE a_num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, a_num);
			rs = pstmt.executeQuery();
			
			if(rs.next())
				answer = rs.getString("answer");
			else
				answer = null;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return answer;
	}
	
	@SuppressWarnings("unchecked")
	public JSONObject SetQuiz(int QN, int PN, byte lvl_min, byte lvl_max, byte type_min, byte type_max) {
		// QN : ���� ���� �� , PN : ���� �� ���� �� , lvl_min/max : ���� ���� , type_min/max : Ÿ�� ����
		
		class Q_A { // q_num , a_num �� ���� Ŭ����
			int q_num;
			int a_num;
			Q_A(int q_num, int a_num) {
				this.q_num = q_num;
				this.a_num = a_num;
			}
		}
		
		Vector<Q_A> v = new Vector<Q_A> (10); // q_num , a_num �� ���� Vector Ŭ����
		int[] answers = new int[PN]; // ���׿� ��� �����(����:1 ����:������)
		JSONObject JSON = new JSONObject();
		System.out.println("Hello~!!");
		try {
			conn = getMysql();
			String sql = "SELECT q_num, a_num FROM default_questions WHERE levels >= ? and levels <= ? "
					+ "and types >= ? and types <= ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setByte(1, lvl_min);
			pstmt.setByte(2, lvl_max);
			pstmt.setByte(3, type_min);
			pstmt.setByte(4, type_max);
			rs = pstmt.executeQuery(); 
			System.out.println("Hello~2!!");
			while(rs.next()) {
				int a = rs.getInt("q_num");
				int b = rs.getInt("a_num");
				v.add(new Q_A(a, b));
			}
			int v_length = v.size(); // ������ ���� (�������� ���� ��ü ����+���� ����)
			int answer_nums[] = QuesAnsNum();
			int a_nums = answer_nums[1]; // ��ü ���� ����
			if(v_length < QN) {
				System.out.println("���� ���� ���� ���� ���� �����մϴ�!");
				JSON = null;
			} else if(a_nums < PN) {
				System.out.println("���� ���� ���� ���� ���� �����մϴ�!");
				JSON = null;	
			} else { // else
				Collections.shuffle(v);
				// Q_A ���� Ŭ�������� �����Ѵ�.
				System.out.println(v.size());
				
				int x, k;
				Vector<Integer> rand_pnum = new Vector<Integer> (10);
				for(int i = 0; i < PN; i++) rand_pnum.add(i+1); // ���� Integer (����) ���� ����
				// ���� 1, 2, ... , PN (��ȣ �����)
				for(int i = 0; i < QN; i++) {
					Collections.shuffle(rand_pnum);
					// ���� 1�� 2�� ... PN�� (1~PN)��  �����Ѵ�.
					// ����(answers[0]) -> ���õ� �迭[0]�� �� (1~PN)
					// ����1(answers[1]) -> ���õ� �迭[1]�� �� (1~PN) 
					// ...
					JSONObject temp = new JSONObject();
					JSONArray temp_array = new JSONArray();
					
					answers[0] = v.elementAt(i).a_num;
					temp.put("q_num", v.elementAt(i).q_num);
					//System.out.println(v.elementAt(i).q_num);
					//System.out.println(GetQuestion(v.elementAt(i).q_num));
					
					temp.put("question", GetQuestion(v.elementAt(i).q_num));
					//System.out.println(GetAnswer(answers[0]));
					
					temp.put("answer", "a" + (int) rand_pnum.elementAt(0));
					temp.put("a" + (int) rand_pnum.elementAt(0), GetAnswer(answers[0]));
					
					for(int j = 1; j < PN; j++) {
						  do {
							x = (int) Math.floor(Math.random() * v_length);
							for(k = 0; k < j; k++) {
								if(answers[k] == v.elementAt(x).a_num)
									break;
							}
						  } while(k != j);
						  // ���� ���� ������ ��Ŀ����
						  answers[j] = v.elementAt(x).a_num;
						  temp.put("a" + (int) rand_pnum.elementAt(j), GetAnswer(answers[j]));
						}
					temp_array.add(temp); // {q_num : xx, question : "������~", a0 : "����", a1 : "����1", ...}
					JSON.put("p" + i, temp_array); // �׷��� JSON�� ������ ���������� �ʴ´�!
				}
				// System.out.println(JSON);
			} // else
		}
		catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
		catch(IOException e) {
			e.printStackTrace();
			return null;
		}
		catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public String GetId(int num) {
		Connection conn2 = null; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		String id;
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		
		try {
			conn2 = getMysql();
			
			String sql = "SELECT id FROM users WHERE num = ?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, num);
			rs2 = pstmt2.executeQuery();
			
			if(rs2.next()) {
				id = rs2.getString("id");
			}
			else
				id = null;
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		}
		
		return id;
	}
	
	public int GetGrade(int num) {
		Connection conn2 = null; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		int grade;
		
		try {
			conn2 = getMysql();
			
			String sql = "SELECT grade FROM users WHERE num = ?";
			pstmt2 = conn.prepareStatement(sql);
			pstmt2.setInt(1, num);
			rs2 = pstmt2.executeQuery();
			
			if(rs2.next()) {
				grade = rs2.getInt("grade");
			}
			else
				grade = -1;
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			return -1;
		} catch(Exception e) {
			e.printStackTrace();
			return -1;
		} finally {
			// closeMysql();
		}
		
		return grade;
	}
	
	public int GetLogged_in(int num) {
		Connection conn2 = null; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		
		int logged_in;
		
		try {
			conn2 = getMysql();
			
			String sql = "SELECT logged_in FROM users WHERE num = ?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, num);
			rs2 = pstmt2.executeQuery();
			
			if(rs2.next()) {
				logged_in = rs2.getInt("logged_in");
			}
			else
				logged_in = -1;
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			return -1;
		} catch(Exception e) {
			e.printStackTrace();
			return -1;
		} finally {
			// closeMysql();
		}
		
		return logged_in;
	}
	
	public boolean SetLogged_in(int num, int setlogged_in) {
		boolean result;
		
		Connection conn2 = null; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		PreparedStatement pstmt2 = null;
		ResultSet rs2 = null;
		
		try {
			conn2 = getMysql();
			
			String sql = "UPDATE users SET logged_in=? WHERE num=?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, setlogged_in);
			pstmt2.setInt(2, num);
			pstmt2.executeUpdate();
			
			result = true;
			
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		} catch(IOException e) {
			e.printStackTrace();
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			// closeMysql();
		}
		
		return result;
	}
	
	public String[] GetDefaultQuizSetAll(int e_num) { // ��¿ �� ���� ���� String���� ����. �ٽ� ��ȯ�� ��!
		String[] Parameters = new String[7]; // ���� ���� ���� ������ DB���� �����Ͽ� �Ķ���ͷ� �������ִ� �Լ�
		
		try {
			conn = getMysql();
			String sql = "SELECT q_nums, a_nums, lvl_min, lvl_max, type_min, type_max, qsecs "
					+ "FROM default_events WHERE e_num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, e_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				Parameters[0] = rs.getString("q_nums");
				Parameters[1] = rs.getString("a_nums");
				Parameters[2] = rs.getString("lvl_min");
				Parameters[3] = rs.getString("lvl_max");
				Parameters[4] = rs.getString("type_min");
				Parameters[5] = rs.getString("type_max");
				Parameters[6] = rs.getString("qsecs");
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return Parameters;
	}
	public String[] GetMultiQuizSetAll(int e_num) { // ��¿ �� ���� ���� String���� ����. �ٽ� ��ȯ�� ��!
		String[] Parameters = new String[11]; // ���� ���� ���� ������ DB���� �����Ͽ� �Ķ���ͷ� �������ִ� �Լ�
		
		try {
			conn = getMysql();
			String sql = "SELECT q_nums, a_nums, lvl_min, lvl_max, type_min, type_max, qsecs, "
					+ "title, img_src, start_day, end_day FROM multi_events WHERE e_num = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, e_num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				Parameters[0] = rs.getString("q_nums");
				Parameters[1] = rs.getString("a_nums");
				Parameters[2] = rs.getString("lvl_min");
				Parameters[3] = rs.getString("lvl_max");
				Parameters[4] = rs.getString("type_min");
				Parameters[5] = rs.getString("type_max");
				Parameters[6] = rs.getString("qsecs");
				Parameters[7] = rs.getString("title");
				Parameters[8] = rs.getString("img_src");
				Parameters[9] = rs.getString("start_day").replace(".0", "");
				Parameters[10] = rs.getString("end_day").replace(".0", "");
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return Parameters;
	}
	
	public int[] ExpPointProcess(int num, int correct, float rate, int P_exp, int P_point) {
		int[] exp_point = new int[2];
		int total_exps; // �ش� ���� �� ����ġ ��
		int total_points; // �ش� ���� �� ����Ʈ ��
		int p_exp = P_exp; // ����Ʈ ���� �� ȹ�� ����ġ
		int p_point = P_point; // ����Ʈ ���� �� ȹ�� ����Ʈ
		
		Connection conn2;
		PreparedStatement pstmt2;
		ResultSet rs2;
		
		try {
			conn2 = getMysql();
			String q_sql = "SELECT exps, points FROM users WHERE num=?";
			pstmt2 = conn2.prepareStatement(q_sql);
			pstmt2.setInt(1, num);
			rs2 = pstmt2.executeQuery();
			
			if(rs2.next()) {
				total_exps = rs2.getInt("exps");
				total_points = rs2.getInt("points");
			} else {
				return null;
			}
			if(rs2 != null) rs2.close(); 
			if(pstmt2 != null) pstmt2.close();
			
			String sql = "UPDATE users SET exps=?, points=? WHERE num=?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, total_exps + (int) (correct * p_exp * rate));
			pstmt2.setInt(2, total_points + (int) (correct * p_point * rate));
			pstmt2.setInt(3, num);
			pstmt2.executeUpdate();
			
			exp_point[0] = (int) (correct * p_exp * rate);
			exp_point[1] = (int) (correct * p_point * rate);
			
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			// closeMysql();
		}
		
		return exp_point;
	}
	
	public boolean SendDefaultRank(byte e_num, int num, int correct, float total_secs) {// e_num : ����Ʈ 0 ~ 5���� ��
		boolean result;
		
		try {
			conn = getMysql();
			String sql = "INSERT INTO default_rank(e_num, num, correct, total_secs) "
					+ "VALUES(?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setByte(1, e_num);
			pstmt.setInt(2, num);
			pstmt.setInt(3, correct);
			pstmt.setFloat(4, total_secs);
			pstmt.executeUpdate();
			
			result = true;
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return result;
	}
	
	public boolean SendMultiRank(byte e_num, int num, int correct, float total_secs) {// e_num : ����Ʈ 0 ~ 5���� ��
		boolean result;
		
		try {
			conn = getMysql();
			String sql = "INSERT INTO multi_rank(e_num, num, correct, total_secs) "
					+ "VALUES(?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setByte(1, e_num);
			pstmt.setInt(2, num);
			pstmt.setInt(3, correct);
			pstmt.setFloat(4, total_secs);
			pstmt.executeUpdate();
			
			result = true;
		} catch(SQLException e) {
			e.printStackTrace();
			return false;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return result;
	}
	
	public JSONObject ShowDefaultRanking(byte e_num, int num) { // �ش� �̺�Ʈ(�ܰ�), id�� �ް� ������ �� �ش� ������ ������ JSON���� �����ִ� �Լ�
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			
			String SQL = "SELECT num, correct, total_secs, rec_day " + 
					"FROM default_rank WHERE e_num=? and num=? ORDER BY correct DESC, total_secs ASC";
			pstmt = conn.prepareStatement(SQL);
			pstmt.setByte(1, e_num);
			pstmt.setInt(2, num);
			rs = pstmt.executeQuery();
			
			int i = 0;
			while(rs.next()) { // null ���϶� �� ������� Ȯ��!!, �� ���� NULL �� ������ֱ�!!
				JSONObject temp = new JSONObject();
				JSONArray temp_array = new JSONArray();
				
				temp.put("rank", (i + 1));
				temp.put("id", GetId(rs.getInt("num")));
				temp.put("correct", rs.getInt("correct"));
				temp.put("total_secs", rs.getFloat("total_secs"));
				temp.put("rec_day", rs.getString("rec_day").replace(".0", ""));
				System.out.println(temp.toString());
				
				temp_array.add(temp);
				JSON.put("r" + i, temp_array); // {"r0" : [{"rank" : 1, "id" : master, "correct" : 5, "total_secs" : 5.42, "rec_day" : 20xx-11-xx 22:33:44}], ...}
				i++;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public JSONObject ShowMultiRanking(byte e_num) { // �ش� �̺�Ʈ(�ܰ�), id�� �ް� ������ �� �ش� ������ ������ JSON���� �����ִ� �Լ�
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			
			String SQL = "SELECT num, correct, total_secs, rec_day " + 
					"FROM multi_rank WHERE e_num=? ORDER BY correct DESC, total_secs ASC";
			pstmt = conn.prepareStatement(SQL);
			pstmt.setByte(1, e_num);
			rs = pstmt.executeQuery();
			
			int i = 0;
			while(rs.next()) {
				JSONObject temp = new JSONObject();
				JSONArray temp_array = new JSONArray();
				
				temp.put("rank", (i + 1));
				temp.put("id", GetId(rs.getInt("num")));
				temp.put("correct", rs.getInt("correct"));
				temp.put("total_secs", rs.getFloat("total_secs"));
				temp.put("rec_day", rs.getString("rec_day").replace(".0", ""));
				
				temp_array.add(temp);
				JSON.put("r" + i, temp_array); // {"r0" : [{"rank" : 1, "id" : master, "correct" : 5, "total_secs" : 5.42, "rec_day" : 20xx-11-xx 22:33:44}], ...}
				i++;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public JSONObject GetBoardList() {
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql = "SELECT * FROM Board ORDER BY p_num ASC";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			int i = 0;
			while(rs.next()) {
				JSONObject temp = new JSONObject();
				JSONArray temp_array = new JSONArray();
				
				temp.put("p_num", rs.getInt("p_num"));
				temp.put("id_num", rs.getInt("id_num"));
				temp.put("id", GetId(rs.getInt("id_num")));
				temp.put("title", rs.getString("title"));
				temp.put("contents", rs.getString("contents"));
				temp.put("cnt", rs.getInt("cnt"));
				temp.put("rec_day", rs.getString("rec_day").replace(".0", ""));
				
				temp_array.add(temp);
				JSON.put("l" + i, temp_array); 
				i++;	
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}

	public JSONObject GetGMBoardList() {
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql = "SELECT * FROM Board WHERE id_num=13 ORDER BY p_num ASC";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			int i = 0;
			while(rs.next()) {
				JSONObject temp = new JSONObject();
				JSONArray temp_array = new JSONArray();
				
				temp.put("p_num", rs.getInt("p_num"));
				temp.put("id_num", rs.getInt("id_num"));
				temp.put("id", GetId(rs.getInt("id_num")));
				temp.put("title", rs.getString("title"));
				temp.put("contents", rs.getString("contents"));
				temp.put("cnt", rs.getInt("cnt"));
				temp.put("rec_day", rs.getString("rec_day").replace(".0", ""));
				
				temp_array.add(temp);
				JSON.put("l" + i, temp_array); 
				i++;	
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}

	
	public JSONObject GetReplyList(int p_num) { // ����Ʈ, ���� �� ������ (ReadBoard�� ���ҵ� ��)
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql = "SELECT * FROM Reply WHERE p_num = ? ORDER BY r_num ASC";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_num);
			rs = pstmt.executeQuery();
			
			int i = 0;
			while(rs.next()) {
				JSONObject temp = new JSONObject();
				JSONArray temp_array = new JSONArray();
				
				temp.put("r_num", rs.getInt("r_num"));
				temp.put("id_num", rs.getInt("id_num"));
				temp.put("id", GetId(rs.getInt("id_num")));
				temp.put("contents", rs.getString("contents"));
				temp.put("rec_day", rs.getString("rec_day").replace(".0", ""));
				
				temp_array.add(temp);
				JSON.put("r" + i, temp_array); 
				i++;	
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public boolean WriteBoard(int id_num, String title, String contents) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "INSERT INTO Board(p_num, id_num, title, contents) "
					+ "VALUES((SELECT IFNULL(MAX(p_num) + 1, 1) FROM Board B), ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			pstmt.setString(2, title);
			pstmt.setString(3, contents);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		
		return result;
	}
	
	//Write Reply
	public boolean WriteReply(int p_num, int id_num, String contents) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "INSERT INTO Reply(p_num, r_num, id_num, contents) "
					+ "VALUES(?, (SELECT IFNULL(MAX(r_num) + 1, 1) FROM Reply R WHERE p_num=?), ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_num);
			pstmt.setInt(2, p_num);
			pstmt.setInt(3, id_num);
			pstmt.setString(4, contents);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	// Update Board
	public boolean UpdateBoard(int p_num, int id_num, String title, String contents) {
		boolean result;
		
		try {
			conn = getMysql();
			String sql = "UPDATE Board SET title=?, contents=?, rec_day=current_timestamp WHERE p_num=? and id_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, contents);
			pstmt.setInt(3, p_num);
			pstmt.setInt(4, id_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
			
		} catch(SQLException e) {
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean DeleteBoard(int p_num, int id_num) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String d_sql2 = "DELETE FROM Reply WHERE p_num=?";
			pstmt = conn.prepareStatement(d_sql2);
			pstmt.setInt(1, p_num);
			int num = pstmt.executeUpdate(); // ���� 0�� �� ���� ����!
			System.out.println("������ ���� �� : " + num);
			
			String d_sql1 = "DELETE FROM Board WHERE p_num=? and id_num=?";
			pstmt = conn.prepareStatement(d_sql1);
			pstmt.setInt(1, p_num);
			pstmt.setInt(2, id_num);
			if(pstmt.executeUpdate() == 0) {
				return false;
			}
			pstmt.close();
			
			result = true;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		
		return result;
	}
	
	// Delete Reply
	public boolean DeleteReply(int p_num, int r_num, int id_num) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "DELETE FROM Reply WHERE p_num=? and r_num=? and id_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_num);
			pstmt.setInt(2, r_num);
			pstmt.setInt(3, id_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean IncreaseCnt(int p_num) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "UPDATE Board SET cnt=cnt+1 WHERE p_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
			System.out.println(result);
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean ChangeId(int id_num, String new_id, int price) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "Update USERS SET id=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, new_id);
			pstmt.setInt(2, id_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			ExpPointProcess(id_num, 1, (float) 1.0, 0, - price);
			// - 10000 ����Ʈ ����!
			
			result = true;
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean ChangePw(int id_num, String new_pw) {
		boolean result;
		
		try {
			conn = getMysql();
			
			String sql = "Update USERS SET pw=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, new_pw);
			pstmt.setInt(2, id_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean CheckOverExp(int id_num, int exp) {
		boolean result;
		
		Connection conn2;
		PreparedStatement pstmt2;
		ResultSet rs2;
		
		try {
			conn2 = getMysql();
			String sql = "SELECT exps FROM USERS WHERE num=?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, id_num);
			rs2 = pstmt2.executeQuery();
			if(rs2.next()) {
				if(rs2.getInt("exps") >= exp) {
					result = true;
				}
				else {
					result = false;
				}
			} else {
				System.out.println("����");
				return false;
			}
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			//closeMysql();
		}
		
		return result;
	}
	
	public boolean CheckOverPoints(int id_num, int points) {
		boolean result;
		
		Connection conn2;
		PreparedStatement pstmt2;
		ResultSet rs2;
		
		try {
			conn2 = getMysql();
			String sql = "SELECT points FROM USERS WHERE num=?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, id_num);
			rs2 = pstmt2.executeQuery();
			if(rs2.next()) {
				if(rs2.getInt("points") >= points) {
					result = true;
				}
				else {
					result = false;
				}
			} else {
				System.out.println("����");
				return false;
			}
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			//closeMysql();
		}
		
		return result;
	}
	
	public boolean LevelUp(int id_num) {
		boolean result;
		
		try {
			conn = getMysql();
			
			int grade = GetGrade(id_num);
			int up_grade = 0;
			int exp_price = 0;
			switch(grade) {
				case 0 :
					if(CheckOverExp(id_num, 10000)) { 
						up_grade = 1; exp_price = 10000;
						break;
					}
					else 
						return false;
				case 1 :
					if(CheckOverExp(id_num, 20000)) { 
						up_grade = 2; exp_price = 20000;
						break;
					}
					else 
						return false;
				case 2 :
					if(CheckOverExp(id_num, 30000)) { 
						up_grade = 3; exp_price = 30000;
						break;
					}
					else 
						return false;
				case 3 :
					if(CheckOverExp(id_num, 50000)) { 
						up_grade = 4; exp_price = 50000;
						break;
					}
					else 
						return false;
				case 4 :
					if(CheckOverExp(id_num, 100000)) { 
						up_grade = 5; exp_price= 100000;
						break;
					}
					else 
						return false;
				default :
					return false;
			}
			
			String sql = "UPDATE USERS SET grade=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, up_grade);
			pstmt.setInt(2, id_num);
			if(pstmt.executeUpdate() == 0)
				return false;
			
			if(pstmt != null) pstmt.close();
			ExpPointProcess(id_num, 1, (float) 1.0, - exp_price, 0);
			
			result = true;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		
		return result;
	}
	
	public boolean CheckBanned(int id_num) {
		boolean result;
		
		Connection conn2; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		PreparedStatement pstmt2;
		ResultSet rs2;
		
		try {
			conn2 = getMysql();
			String sql = "SELECT num FROM USERS WHERE current_timestamp > banned_start_day and current_timestamp < banned_end_day and num = ?";
			pstmt2 = conn2.prepareStatement(sql);
			pstmt2.setInt(1, id_num);
			rs2 = pstmt2.executeQuery();
			
			if(rs2.next()) {
				System.out.println("Banned [id_num] : " + rs2.getInt("num"));
				result = true;
			} else {
				result = false;
			}
			
			if(rs2 != null) rs2.close();
			if(pstmt2 != null) pstmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		}
		
		return result;
	}
	
	public int GetUserNum() {
		int N = 0;
		
		Connection conn2; // �ٸ� DAO �Լ� ��� ���߿� �� ���� ���ɼ��� �����Ƿ�, Ŭ���� �����ʹ� �ٸ� ������ �����ؾ� �Ѵ�.
		Statement stmt2;
		ResultSet rs2;
		
		try {
			conn2 = getMysql();
			String sql= "SELECT COUNT(*) as nums FROM USERS";
			stmt2 = conn2.createStatement();
			rs2 = stmt2.executeQuery(sql);
			
			if(rs2.next())
				N = rs2.getInt("nums");
			else
				return 0;
	
			if(rs2 != null) rs2.close();
			if(stmt2 != null) stmt2.close();
			if(conn2 != null) conn2.close();
			
		} catch(SQLException e) {
			e.getStackTrace();
			return 0;
		} catch(Exception e) {
			e.getStackTrace();
			return 0;
		}
		
		return N;
	}
	
	public JSONObject SearchAllUsers() {
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql="SELECT * FROM USERS";
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql);
			
			int i = 0;
			while(rs.next()) {
				JSONObject temp = new JSONObject();
				JSONArray array = new JSONArray();
				
				temp.put("id_num", rs.getInt("num"));
				temp.put("logged_in", rs.getByte("logged_in"));
				temp.put("id", rs.getString("id"));
				temp.put("pw", rs.getString("pw"));
				temp.put("grade", rs.getByte("grade"));
				temp.put("exps", rs.getInt("exps"));
				temp.put("points", rs.getInt("points"));
				if(rs.getString("banned_start_day") != null && rs.getString("banned_end_day") != null) {
					JSON.put("banned_start_day", rs.getString("banned_start_day").replace(".0", ""));
					JSON.put("banned_end_day", rs.getString("banned_end_day").replace(".0", ""));
				} else {
					JSON.put("banned_start_day", rs.getString("banned_start_day"));
					JSON.put("banned_end_day", rs.getString("banned_end_day"));
				}
				array.add(temp);
				JSON.put("l" + i, array);
				i++;
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public JSONObject GetUserByName(String id) {
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql="SELECT * FROM USERS WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				JSON.put("id_num", rs.getInt("num"));
				JSON.put("logged_in", rs.getByte("logged_in"));
				JSON.put("id", rs.getString("id"));
				JSON.put("pw", rs.getString("pw"));
				JSON.put("grade", rs.getByte("grade"));
				JSON.put("exps", rs.getInt("exps"));
				JSON.put("points", rs.getInt("points"));
				if(rs.getString("banned_start_day") != null && rs.getString("banned_end_day") != null) {
					JSON.put("banned_start_day", rs.getString("banned_start_day").replace(".0", ""));
					JSON.put("banned_end_day", rs.getString("banned_end_day").replace(".0", ""));
				} else {
					JSON.put("banned_start_day", rs.getString("banned_start_day"));
					JSON.put("banned_end_day", rs.getString("banned_end_day"));
				}
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public JSONObject GetUserByNum(int id_num) {
		JSONObject JSON = new JSONObject();
		
		try {
			conn = getMysql();
			String sql="SELECT * FROM USERS WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				JSON.put("id_num", rs.getInt("num"));
				JSON.put("logged_in", rs.getByte("logged_in"));
				JSON.put("id", rs.getString("id"));
				JSON.put("pw", rs.getString("pw"));
				JSON.put("grade", rs.getByte("grade"));
				JSON.put("exps", rs.getInt("exps"));
				JSON.put("points", rs.getInt("points"));
				if(rs.getString("banned_start_day") != null && rs.getString("banned_end_day") != null) {
					JSON.put("banned_start_day", rs.getString("banned_start_day").replace(".0", ""));
					JSON.put("banned_end_day", rs.getString("banned_end_day").replace(".0", ""));
				} else {
					JSON.put("banned_start_day", rs.getString("banned_start_day"));
					JSON.put("banned_end_day", rs.getString("banned_end_day"));
				}
			}
			
		} catch(SQLException e) {
			e.getStackTrace();
			return null;
		} catch(Exception e) {
			e.getStackTrace();
			return null;
		} finally {
			closeMysql();
		}
		
		return JSON;
	}
	
	public boolean SetUser(int id_num, int num, byte logged_in, String id, String pw, byte grade, int exps, int points, String banned_start_day, String banned_end_day) {
		boolean result;
		try {
			conn = getMysql();
			String sql="UPDATE USERS SET num=?, logged_in=?, id=?, pw=?, grade=?, exps=?, points=?, banned_start_day=?, banned_end_day=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setByte(2, logged_in);
			pstmt.setString(3, id);
			pstmt.setString(4, pw);
			pstmt.setByte(5, grade);
			pstmt.setInt(6, exps);
			pstmt.setInt(7, points);
			if(banned_start_day == null)
				pstmt.setNull(8, java.sql.Types.DATE);
			else
				pstmt.setString(8, banned_start_day);
			if(banned_end_day == null)
				pstmt.setNull(9, java.sql.Types.DATE);
			else
				pstmt.setString(9, banned_end_day);
			pstmt.setInt(10, id_num);
			
			if(pstmt.executeUpdate() == 0)
				return false;
			
			result = true;
			
		} catch(SQLException e) {
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
	
	public boolean DeleteUser(int id_num) {
		boolean result;
		
		try {
			SetLogged_in(id_num, 0); // �α׾ƿ���Ŵ
			
			conn = getMysql();
			System.out.println("test");
			
			String sql = "DELETE FROM REPLY WHERE id_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			if(pstmt.executeUpdate() == 0) { // ��� ������ ���� �ִ�.
				System.out.println("[id_num] : " + id_num + ", ���� ��ü ���� ����");
			} else {
				System.out.println("[id_num] : " + id_num + ", ���� ��ü ���� ����");
			}
			pstmt.close();
			
			sql = "DELETE FROM Board WHERE id_num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			if(pstmt.executeUpdate() == 0) { // ��� ������ ���� �ִ�.
				System.out.println("[id_num] : " + id_num + ", �Խ��� ��ü ���� ����");
			} else {
				System.out.println("[id_num] : " + id_num + ", �Խ��� ��ü ���� ����");
			}
			pstmt.close();
			
			sql = "DELETE FROM MULTI_RANK WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			if(pstmt.executeUpdate() == 0) { // ��� ������ ���� �ִ�.
				System.out.println("[id_num] : " + id_num + ", ��Ƽ��ŷ ��ü ���� ����");
			} else {
				System.out.println("[id_num] : " + id_num + ", ��Ƽ��ŷ ��ü ���� ����");
			}
			pstmt.close();
			
			sql = "DELETE FROM DEFAULT_RANK WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			if(pstmt.executeUpdate() == 0) { // ��� ������ ���� �ִ�.
				System.out.println("[id_num] : " + id_num + ", ���η�ŷ ��ü ���� ����");
			} else {
				System.out.println("[id_num] : " + id_num + ", ���η�ŷ ��ü ���� ����");
			}
			pstmt.close();
			
			sql = "DELETE FROM USERS WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, id_num);
			if(pstmt.executeUpdate() == 0) { // �̰� ������ �����ؾ� ��!
				System.out.println("[id_num] : " + id_num + ", ���� ���� ����");
				return false;
			}
			
			System.out.println("[id_num] : " + id_num + ", ���� ���� ����");
			result = true;
			
		} catch(SQLException e) {
			System.out.println("[Delete] SQL Error!");
			e.getStackTrace();
			return false;
		} catch(Exception e) {
			System.out.println("[Delete] Exception Error!");
			e.getStackTrace();
			return false;
		} finally {
			closeMysql();
		}
		
		return result;
	}
}
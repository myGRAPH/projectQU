package quiz;

import java.io.*;
import java.util.*;
import java.text.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 * Servlet implementation 
 */
@WebServlet("/ChatQuiz")
public class ChatQuiz extends HttpServlet {
	
	String message[];
	//�������� �Է��� �޽����� �����ϴ� �κ�
	String msg_color[];
	//���� ���ѿ� ���� �÷���
	
	int index = 0 , size = 15;
	
	public void init() {
		message = new String[size];
		msg_color = new String[size];
		for(int i=0; i<size; i++)
		{
			message[i] = "";
			msg_color[i] ="Black";
			// �ʱ�ȭ �� �� ���� ǥ��
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException{ // �޽��� ���� �� ����Ǵ� ����
			
			
			String id = req.getParameter("id");
			String msg = req.getParameter("msg");
			int grade= Integer.parseInt(req.getParameter("grade"));
			
			if(msg!=null && msg.trim().length() != 0) {
				synchronized(message){
					if(index == size) { // ������ �� ����
						for(int i = 0; i < size - 1; i++) {
						message[i] = message[i + 1];
						msg_color[i] = msg_color[i + 1];
						}
						index = size - 1;
					}
					
					message[index] = id + " : " + msg;
					//�޽����� 'id : �Է��� �޽��� ����'���� ������ �ǰ� ���� �߽��ϴ�.
					switch(grade) {
						case 0 :
							msg_color[index] = "Black";
							break;
						case 1 :
							msg_color[index] = "SlateGray";
							break;
						case 2 :
							msg_color[index] = "Chocolate";
							break;
						case 3 :
							msg_color[index] = "RoyalBlue";
							break;
						case 4 :
							msg_color[index] = "OrangeRed";
							break;
						case 5 :
							msg_color[index] = "Crimson";
							break;
						case 6 :
							msg_color[index] = "Red";
							break;
							
						default :
							msg_color[index] = "Black";
							break;
					} // ���(����)�� ���� �۾��� ����
					
					index = (index + 1);
				} 
			}
			// doGet(req, res);
			res.setContentType("text/html; charset=utf-8");
			PrintWriter out = res.getWriter();
			JSONObject JSON = new JSONObject();
			
			// java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
			// String today = formatter.format(new java.util.Date());
			for(int i = 0; i < size; i++) {
				JSON.put("msg" + i, message[i]);
				JSON.put("msg_color" + i, msg_color[i]);
			}	
			// System.out.println(JSON);
			out.println(JSON.toJSONString());
	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException{ // �ڵ����� ǥ�õǴ� ����
		String first = req.getParameter("first");		
		// System.out.println("First �� : " + first);
		// ù ���� ǥ��
		
		if(first.equals("Y")) {
			HttpSession session = req.getSession();
			String id = session.getAttribute("sessionId").toString();
			int grade= Integer.parseInt(session.getAttribute("sessionGrade").toString());
			
			synchronized(message) {
				if(index == size) { // ������ �� ����
					for(int i = 0; i < size - 1; i++) {
					message[i] = message[i + 1];
					msg_color[i] = msg_color[i + 1];
					}
					index = size - 1;
				}
				
				message[index] = id +" ���� ���Խ��ϴ�.";
				switch(grade) {
					case 0 :
						msg_color[index] = "Black";
						break;
					case 1 :
						msg_color[index] = "SlateGray";
						break;
					case 2 :
						msg_color[index] = "Chocolate";
						break;
					case 3 :
						msg_color[index] = "RoyalBlue";
						break;
					case 4 :
						msg_color[index] = "OrangeRed";
						break;
					case 5 :
						msg_color[index] = "Crimson";
						break;
					case 6 :
						msg_color[index] = "Red";
						break;
					
					default :
						msg_color[index] = "Black";
						break;
				} // ���(����)�� ���� �۾��� ����
				
				index = (index + 1);
			}
		}
		
		res.setContentType("text/html; charset=utf-8");
		PrintWriter out = res.getWriter();
		JSONObject JSON = new JSONObject();
		
		// java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyyMMddHHmmss");
		// String today = formatter.format(new java.util.Date());
		for(int i = 0; i < size; i++) {
			JSON.put("msg" + i, message[i]);
			JSON.put("msg_color" + i, msg_color[i]);
		}
		// System.out.println(JSON.toJSONString());
		out.println(JSON.toJSONString());
	}
}


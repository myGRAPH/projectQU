package quiz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import quiz.DAO;

public class userBeans {
	private int num;
	private byte logged_in;
	private String id;
	private String pw;
	private byte grade;
	private int exps;
	private int points;
	private String banned_start_day;
	private String banned_end_day;
	
	public void setAll(String id, String pw) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		DAO dao = DAO.getInstance();
		
		try {
			conn = dao.getMysql();
			String sql = "SELECT * FROM users WHERE id=? and pw=?";
			pstmt = conn.prepareStatement(sql);
			// System.out.println(id + ":" + pw);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			
			rs = pstmt.executeQuery(); 
			if(rs.next()) {
				this.num = rs.getInt("num");
				this.logged_in = rs.getByte("logged_in");
				this.id = rs.getString("id");
				this.pw = rs.getString("pw");
				this.grade = rs.getByte("grade");
				this.exps = rs.getInt("exps");
				this.points = rs.getInt("points");
				this.banned_start_day = rs.getString("banned_start_day");
				this.banned_end_day = rs.getString("banned_end_day");
			}
		} 
		catch (Exception e) {
			System.out.println("setAll() ���� �߻�");
			e.printStackTrace();
		}
	}
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public byte getLogged_in() {
		return logged_in;
	}
	public void setLogged_in(byte logged_in) {
		this.logged_in = logged_in;
	}
	public String getBanned_start_day() {
		return banned_start_day;
	}
	public void setBanned_start_day(String banned_start_day) {
		this.banned_start_day = banned_start_day;
	}
	public String getBanned_end_day() {
		return banned_end_day;
	}
	public void setBanned_end_day(String banned_end_day) {
		this.banned_end_day = banned_end_day;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public byte getGrade() {
		return grade;
	}
	public void setGrade(byte grade) {
		this.grade = grade;
	}
	public int getExps() {
		return exps;
	}
	public void setExps(int exps) {
		this.exps = exps;
	}
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
}
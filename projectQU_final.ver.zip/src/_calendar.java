 

import java.io.*;
import java.util.Date;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/_caldndar")
public class _calendar extends HttpServlet{
 public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException { 
  PrintWriter pout = new PrintWriter(new OutputStreamWriter(res.getOutputStream(),"KSC5601"));
  res.setContentType("text/html; charset=euc-kr"); 
  Date toDay = new Date(); 
  Date sDate = new Date(); 
  Date eDate = new Date(); 
  
  String pMonth = req.getParameter("month");
  if (pMonth!=null){
   toDay.setMonth( Integer.parseInt(pMonth) ); 
   sDate.setMonth( Integer.parseInt(pMonth) ); 
   eDate.setMonth( Integer.parseInt(pMonth) ); 
  }
  sDate.setDate(1); 
  eDate.setDate(1); 
  eDate.setMonth( eDate.getMonth() + 1); 
  eDate.setDate( eDate.getDate() - 1); 
  String sMonth = "0" + (toDay.getMonth()+1); 
  sMonth = sMonth.substring(sMonth.length()-2);
  pout.println("<HTML><HEAD><TITLE>�޷�</TITLE>"); 
  pout.println("<scRIPT language='Javascript'>");  
  pout.println("<!-- "); 
  pout.println("var "); 
  pout.println(" Mess = \"" + (1900 + toDay.getYear()) + "-" + sMonth + "\";"); 
  pout.println("function mouseclick(inx) { "); 
  pout.println(" var aStr = '0' + inx; "); 
  pout.println(" alert( Mess + '-' + aStr.substr(aStr.length-2,2) ); "); 
  pout.println("} "); 
  pout.println("function mouseover() { "); 
  pout.println(" if ('TD' == event.srcElement.tagName & '' != event.srcElement.innerText) { "); 
  pout.println("  event.srcElement.style.backgroundColor = 'yellow'; "); 
  pout.println("  event.srcElement.style.color = 'red'; "); 
  pout.println(" } "); 
  pout.println("} "); 
  pout.println("function mouseout() { "); 
  pout.println(" if ('TD' == event.srcElement.tagName & '' != event.srcElement.innerText){ "); 
  pout.println("  event.srcElement.style.backgroundColor = ''; "); 
  pout.println("  event.srcElement.style.color = ''; "); 
  pout.println(" } "); 
  pout.println("} ");
  pout.println("function MonthClick(inx) {");
  pout.println(" location.href = 'CalendarServ?month='+(" + toDay.getMonth() + " + inx);");
  pout.println("}"); 
  pout.println("--> "); 
  pout.println("</scRIPT> </HEAD> <BODY><CENTER> <H1>�޷�</H1> "); 
  pout.println("<TABLE border='1' bgcolor='#00FF00' cellspacing=1 width=50% height=50%> "); 
  pout.println("<TR> "); 
 
  String days[] = {"��", "��", "ȭ", "��", "��", "��", "��"}; 
  final String TD_Color = "bgcolor='#FFFFFF' bordercolor='#FFFFFF'";
  pout.println("<TD align='center' colspan=7 height=30 " + TD_Color + ">"); 
  pout.println("<a href='javascript:onclick=MonthClick(-1)'><</a>"); 
  pout.println( 1900 + toDay.getYear() + "-" + sMonth ); 
  pout.println("<a href='javascript:onclick=MonthClick(1)'>></a>" + "</TD></TR>");
  for( int i=0; i<days.length; i++) 
   pout.println("<TD height=30 align='center' " + TD_Color + ">" + days[i] + "</TD>");
  pout.println("</TR><TR>"); 
  int seqWeek = sDate.getDay(); 
  for( int i=0; i<seqWeek; i++) 
   pout.println("<TD " + TD_Color + "> </TD>");
  while (sDate.getDate() <= eDate.getDate()) { 
   seqWeek = sDate.getDay(); 
   int inx = sDate.getDate(); 
   pout.println( "<TD " + TD_Color + "style='cursor:hand' onmouseover=mouseover() onmouseout=mouseout() onClick=mouseclick(" + inx + ")>"+ inx + "</TD>");
   if (seqWeek == 6) pout.println("</TR><TR>"); 
   if (sDate.getDate() == eDate.getDate()) break; 
   sDate.setDate( inx+ 1); 
  } 
  for( int i=seqWeek+1; i<7; i++) pout.println("<TD " + TD_Color + "> </TD>"); 
  pout.println("</TR> </TABLE> </CENTER></BODY> </HTML>");
  pout.close();
 }
}
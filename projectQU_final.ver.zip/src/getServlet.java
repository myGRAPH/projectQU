import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/getServlet")

public class getServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{

			    String name = req.getParameter("name");
			    byte b[] = name.getBytes("ISO-8859-1");
			    name = new String(b, "UTF-8");
			    
			    res.setContentType("text/html; charset=utf-8");
			     
			    String id = req.getParameter("id");
			    String msg = name + "���� ���̵��" + id + "�Դϴ�."; 
			    
			    PrintWriter out = res.getWriter();

			    out.println("<html>");
			    out.println("<body>");
			    out.println(msg);
			    out.println("</body>");
			    out.println("</html>");
	}
}

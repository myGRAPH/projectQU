import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servlet/FruitTest")

public class ServletFruit extends HttpServlet{
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException{

		req.setCharacterEncoding("utf-8");
		String name = req.getParameter("name");
		String gender = req.getParameter("gender");
		String[] fruit = req.getParameterValues("fruit");

		String msg = "";
		if(fruit==null){
			msg = name+"���� ��̴� �����ϴ�."; 
		}else{
			msg = name+"���� ��̴�";
			for(int i=0; i<fruit.length; i++){
			msg += fruit[i]+" ";
			}
			msg += "�Դϴ�.";
		}
		
		res.setContentType("text/html; charset=utf-8");
		PrintWriter out = res.getWriter();

		out.println("<html>");
		out.println("<body>");
		out.println(msg);
		out.println("</body>");
		out.println("</html>");
	}	
}


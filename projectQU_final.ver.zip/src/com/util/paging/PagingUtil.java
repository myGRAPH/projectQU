package com.util.paging;

public class PagingUtil {
	public static PagingBean setPagingInfo(PagingBean paging){
	
		paging.setStartNum(paging.getTotalCount() - (paging.getNowPage()-1) * paging.getCountPerPage());
		
		
		//시작 seq
		paging.setStartseq(paging.getTotalCount()-paging.getStartNum()); 
		//종료 seq
		paging.setEndseq(paging.getTotalCount()-paging.getStartNum()+paging.getCountPerPage());
		
		
		return paging;
	}
}

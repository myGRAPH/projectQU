package sample;

public class My {
	public String getText() {
        return "Hello";
	}
}

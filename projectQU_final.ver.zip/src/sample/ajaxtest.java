package sample;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import org.json.simple.*;

@WebServlet(urlPatterns="/Ttest/ajaxtest")

public class ajaxtest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		// doPost(request, response);
	}

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		String val = request.getParameter("val");
		  String num = request.getParameter("num");

		  System.out.println(val);
		  System.out.println(num);

		  // return type�� json����
		  JSONObject obj = new JSONObject();
		  obj.put("result", "fail");

		  response.setContentType("application/x-json; charset=UTF-8");
		  response.getWriter().print(obj);
	}
}
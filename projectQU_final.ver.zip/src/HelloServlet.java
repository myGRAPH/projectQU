import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/HelloServlet/*")
/*public class HelloServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public HelloServlet() {
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<TITLE>Hello ������</TITLE>");
		out.println("</HEAD>");
		out.println("<BODY BGCOLOR='white'>");
		out.println("<B>Hello, ������</B>");
		out.println("</BODY>");
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}*/
public class HelloServlet extends GenericServlet{
	public void service(ServletRequest req, ServletResponse res)
	throws IOException, ServletException{
		String msg = "Hellow Servlet";
		PrintWriter out = res.getWriter();
		out.println("<html>");		
		out.println("<body>");
		out.println(msg);
		out.println("</body>");
		out.println("</html>");
   }
} 

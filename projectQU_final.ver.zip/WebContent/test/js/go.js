/**
 * 
 */
	function ajaxGo() {
		jQuery.ajax({
			type : "GET",
			url : "linkRequestStd.jsp",
			data : {
				num : $("select[name=num]").val()
			},
			datatype : "JSON",
			success : function(obj) {
				var data = JSON.parse(obj);
				console.log(data);
				$("div #num").text(data.num);
				$("div #msg").text(data.msg);
			},
			complete : function(data) {// 응답이 종료되면 실행, 잘 사용하지않는다
				console.log(data);
			},
			error : function(xhr, status, error) {
				alert("ERROR!!!");
			}
		});
	}
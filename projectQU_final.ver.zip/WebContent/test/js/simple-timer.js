/**
 * 
 */
var timerStart = true;
var Start = new Date();
var End;
function myTimer()
{	
   postMessage(0.1);   
}


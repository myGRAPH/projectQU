
function getContextPath() { // 절대경로 구하기
    	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
    	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
    };

setInterval(function() {
	var xhr = new XMLHttpRequest();
	var data = {"send" : "hi"};

xhr.open('POST', getContextPath() + "/test/worker_transfer_data.jsp", true);
xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

xhr.onload = function() {
	  if (xhr.status === 200 || xhr.status === 201) {
		  postMessage(JSON.parse(xhr.response));
	  } else {
		  postMessage("Error");
	  }
};

xhr.responseType = 'json'; // 응답 파일 설정
xhr.send("send=hi"); 
}, 5000);

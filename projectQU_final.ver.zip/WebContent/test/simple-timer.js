/**
 * 
 */
var timerStart = true;

function myTimer()
{
   postMessage(0.1);
}
                
if (timerStart){
   myVar=setInterval(function(){myTimer()},100);
   timerStart = false;
}
/**
 * 
 */
var chat_size = 15;
var chatworker;

function getContextPath() { // 절대경로 구하기
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};

function GetChat() {
	$("#Chat_Frame").show();
	chatWorker();
}

function CloseChat() {
	$("#Chat_Frame").hide();
	stopchatWorker();
}


function SendChat() {
	var url_ = getContextPath() + "/ChatQuiz";
	$.ajax({
		type : "POST",
		url : url_,
		data : {id : $("#sessionId").val(), msg : $("#ChatBox").val(), grade : $("#sessionGrade").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			$("#ChatBox").val("");
			//alert(Object.keys(data).length);	
		
			for(var i = 0; i < chat_size; i++) {
				//alert(eval("data.msg" + String(i)));
				//alert(eval("data.msg_color" + String(i)));
				$("#msg" + i).text(eval("data.msg" + String(i)));
				$("#msg" + i).css("color", eval("data.msg_color" + String(i)));
			}
		},
		error : function(e) {
			alert('Error! (Chat)');
			return false;
		}
	});
}

function chatWorker(){      
    if(!!window.Worker){ //브라우저가 웹 워커를 지원하는지 검사한다    
      // alert("chatworker on");
      if(chatworker) chatworker.terminate();      //워커가 이미 존재하면 종료시킨다                     
      chatworker = new Worker(getContextPath() + "/QUIZ/JS/chatworker.js");  //새로운 워커(객체)를 생성한다       
                   
      chatworker.onmessage = function(event) { //워커로부터 전달되는 메시지를 받는다
      	var obj = event.data;
      	// alert("여기서발생");
      	// alert(obj);
      		for(var i = 0; i < chat_size; i++) {
				$("#msg" + i).text(eval("obj.msg" + String(i)));
				$("#msg" + i).css("color", eval("obj.msg_color" + String(i)));	
      	}
      };                    
    }
    else{
      alert("현재 브라우저는 웹 워커를 지원하지 않습니다")
    }
}
  
 function stopchatWorker() {
    if(chatworker) {
      chatworker.terminate();
      // alert("워커 작업이 중지되었습니다");
    }
  }

$(document).ready(function() {
	$("#Chat_Frame").hide();
	
	$("#ChatBox").keydown(function(key) { // 엔터키 대응
		if (key.keyCode == 13) {
			SendChat();
		}
	});
});
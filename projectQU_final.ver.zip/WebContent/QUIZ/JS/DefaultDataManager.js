/**
 * 
 **/
var temp_question;
var temp_answer;
var temp_levels;
var temp_values;
// 변경, 추가, 삭제를 위한 임시 변수(조회한 값들을 임시로 저장한다.)

function ajaxQuesAnsNum() { // 문제, 정답 갯수 표시 함수
	$.ajax({
		type : "POST",
		url : "default_data_num.jsp",
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var q_nums = String(data.q_nums);
			var a_nums = String(data.a_nums);
			$('#q_nums').text(q_nums);
			$('#a_nums').text(a_nums);
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

$(document).ready(function () { //[바로 실행] 문제, 정답 갯수 표시 함수 (1분 간격)
	ajaxQuesAnsNum();
	setInterval(function ajaxQuesAnsNum() { // 익명 함수로 직접 입력해야 반복 실행 가능!
		$.ajax({
			type : "POST",
			url : "default_data_num.jsp",
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				var q_nums = String(data.q_nums);
				var a_nums = String(data.a_nums);
				$('#q_nums').text(q_nums);
				$('#a_nums').text(a_nums);
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
	}, 60000);
});

function ajaxSearchQlike() {
	if($('#p_like').val() == "") {
		alert("검색할 단어를 입력해 주세요!");
		return false;
	}
	var p_like = $('#p_like').val();
	// alert(p_like);
	
	$.ajax({
		type : "POST",
		url : "default_data_find_search.jsp",
		data : {p_like : p_like},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var q_nums = String(data.q_nums);
			$('#q_find_num').text(data.q_nums);
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxSearchQnum() {
	if($('#p_num').val() == "") {
		alert("찾을 문제 번호를 입력해 주세요!");
		return false;
	}
	else if(parseInt($('#p_num').val()) > parseInt($('#q_nums').text()) || parseInt($('#p_num').val()) <= 0) {
		
		alert("문제 번호 범위에 맞게 입력해 주세요!");
		return false;
	}
	var q_num = $('#p_num').val();

	$.ajax({
		type : "POST",
		url : "default_data_find_num.jsp",
		data : {q_num : q_num},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var question = String(data.question);
			var answer = String(data.answer);
			var a_num = String(data.a_num);
			var levels = String(data.levels);
			var types = String(data.types);
			//alert(question); alert(answer); alert(a_num);
			$('#question').text(question);
			$('#q_num').val(q_num); //히든 값(문제 번호) 입력(검색했음을 표시)
			$('#answer').val(answer);
			$('#a_num').val(a_num); //히든 값(정답 번호) 입력(검색했음을 표시)
			$('#levels').val(levels);
			$('#types').val(types);
			temp_question = question;
			temp_answer = answer;
			temp_levels = levels;
			temp_types = types;
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxAddQuestion() {
	if($('#q_num').val() == "" || $('#a_num').val() == "") {
		alert("추가할 문제(정답)번호를 조회 후 이용해 주세요!");
		return false;
	}
	if(temp_question == $('#question').text()) {
		alert("같은 문제 내용을 추가할 순 없습니다!");
		return false;
	}
	
	var question = $('#question').text();
	var a_num = $('#a_num').val();
	var levels = temp_levels;
	var types = temp_types;
	
	$.ajax({
		type : "POST",
		url : "default_data_add_question.jsp",
		data : {question_ : question, a_num_ : a_num, levels_ : levels, types_ : types},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var Result = String(data.result);
			// alert(Result);
			if(Result == "Y") {
				alert('문제 생성 성공!');
				$('#question').text("");
				$('#q_num').val("");
				$('#answer').val("");
				$('#a_num').val("");
				$('#levels').val("");
				$('#types').val("");
				ajaxQuesAnsNum(); // 문제 갯수 표시 갱신
			} else {
				alert('문제 생성 실패!');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxUpdateQuestion() {
	if($('#q_num').val() == "" || $('#a_num').val() == "") {
		alert("변경할 문제 번호를 조회 후 이용해 주세요!");
		return false;
	}
	if(temp_question == $('#question').text()) {
		alert("같은 문제 내용으로 변경할 순 없습니다!");
		return false;
	}
	
	var question = $('#question').text();
	var q_num = $('#q_num').val();
	var levels = temp_levels;
	var types = temp_types;
	// alert(question); alert(q_num); alert(levels); alert(types);
	
	$.ajax({
		type : "POST",
		url : "default_data_update_question.jsp",
		data : {question_ : question, q_num_ : q_num},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var Result = String(data.result);
			// alert(Result);
			if(Result == "Y") {
				alert('문제 변경 성공!');
				temp_question = question;
				// ajaxQuesAnsNum(); 갱신할 필요가 없음
			} else {
				alert('문제 변경 실패!');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxUpdateAnswer() {
	if($('#q_num').val() == "" || $('#a_num').val() == "") {
		alert("변경할 문제 번호를 조회 후 이용해 주세요!");
		return false;
	}
	if(temp_answer == $('#answer').val()) {
		alert("같은 정답 내용으로 변경할 순 없습니다!");
		return false;
	}
	
	var answer = $('#answer').val();
	var a_num = $('#a_num').val();
	var levels = temp_levels;
	var types = temp_types;
	// alert(answer); alert(a_num); alert(levels); alert(types);
	
	$.ajax({
		type : "POST",
		url : "default_data_update_answer.jsp",
		data : {answer_ : answer, a_num_ : a_num},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var Result = String(data.result);
			// alert(Result);
			if(Result == "Y") {
				alert('정답 변경 성공!');
				temp_answer = answer;
				// ajaxQuesAnsNum(); 갱신할 필요가 없음
			} else {
				alert('정답 변경 실패!');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxUpdateLevelType() {
	if($('#q_num').val() == "" || $('#a_num').val() == "") {
		alert("변경할 문제 번호를 조회 후 이용해 주세요!");
		return false;
	}
	if(temp_levels == $('#levels').val() && temp_types == $('#types').val()) {
		alert("레밸, 타입 중 한가지 이상 변경해 주세요!");
		return false;
	}
	
	var q_num = $('#q_num').val();
	var a_num = $('#a_num').val();
	var levels = $('#levels').val();
	var types = $('#types').val();
	// alert(levels); alert(types);
	
	$.ajax({
		type : "POST",
		url : "default_data_update_lvl_type.jsp",
		data : {q_num_ : q_num, a_num_ : a_num, levels_ : levels, types_ : types},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var Result = String(data.result);
			// alert(Result);
			if(Result == "Y") {
				alert('레밸/타입 변경 성공!');
				temp_levels = levels;
				temp_types = types;
				// ajaxQuesAnsNum(); 갱신할 필요가 없음
			} else {
				alert('레밸/타입 변경 실패!');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}
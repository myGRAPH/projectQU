var _Nums; // 총 문제 수
var _SNums; // 문항 수
var Questions; // 문제
var Answers; // 정답
var Selects; // 선택 
var Count; // 현재 진입 중인 문제 번호
var Correct; // 정답 수
var Wrong; // 오답 수
var TotalSecs; // 걸리는 시간
var QSecs; // 문제당 제한 시간
var MyAnswer; // 내가 작성한 답
var timer; // 인터벌 정지 위한 변수

function Init() {
	_Nums = Number($('#QN').val());
	_SNums = Number($('#PN').val());
	Questions  = new Array(_Nums);
	Answers  = new Array(_Nums);
	Selects = new Array(_Nums);
	for(var i = 0; i < _Nums; i++)
		Selects[i] = new Array(_SNums);
	Count = 0; Correct = 0; Wrong = 0; TotalSecs = 0;
	QSecs = Number($('#q_secs').val()); // 하.. 개씨X 진짜..
	MyAnswer = 0;
	// alert(QSecs);
}
function MakeQuiz() {
		var QNS = _Nums;
		var PNS = _SNums;
		var lvl_mins = $('#lvl_min').val();
		var lvl_maxs = $('#lvl_max').val();
		var type_mins = $('#type_min').val();
		var type_maxs = $('#type_max').val();
		// alert(QNS); alert(PNS); alert(lvl_mins); alert(lvl_maxs); alert('1 '+type_mins); alert('2 '+type_maxs);
		$.ajax({
		type : "POST",
		url : "test_quiz_set.jsp",
		data : {QN_ : QNS, PN_ : PNS, lvl_min_ : lvl_mins, lvl_max_ : lvl_maxs, type_min_ : type_mins, type_max_ : type_maxs},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data);
			
			for(var i = 0; i < QNS; i++) {
				Questions[i] = String(eval("data.p" + String(i) + "[0].question"));
				Answers[i] = String(eval("data.p" + String(i) + "[0].answer")).replace("a", "");
				
				
				for(var j = 1; j <= PNS; j++) {
					Selects[i][j-1] = String(eval("data.p" + String(i) + "[0].a" + j));
				}
			} 
			
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}


$(document).click(function(event) { // 버튼 아이디 접근할 방법이 이거 밖에 없다...
	var btn_id = event.target.getAttribute('id');
	for(var i = 1; i <= _SNums; i++) {
		if(String(btn_id) == ("btn" + String(i))) {
				MyAnswer = i;
				break;
		}
	}
});
function send() {
	$('#QNums').val(_Nums);
	$('#Correct').val(Correct);
	$('#Wrong').val(Wrong);
	$('#TotalSecs').val(TotalSecs.toFixed(2));
	document.frm1.submit();
}

function getContextPath() { // 어플리케이션까지 절대경로 구하기
	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};

function Play() {
	var w = null; // Web-Worker 변수
	//alert(Questions[0]);
	//alert(Answers[0]);
	//alert(Selects[0][0]);
	//alert('시작');
	var temp = QSecs;
	$('#timers').text(String(temp.toFixed(2)) + "초");
	$('#question').text("[" + String(Count + 1) + "] : " + Questions[Count]);
 	for(var i = 0; i < _SNums; i++)
		$('#answer' + Number(i + 1)).text(Number(i + 1) + " : " + Selects[Count][i]);
 	var answer = Answers[Count]; // String "1" "2" "3" ...

	if (typeof(Worker)!=="undefined") {  
		if (w == null){
	        w = new Worker(getContextPath() + "/QUIZ/JS/timer.js");
	    }
		
	    // Update timer div with output from Web Worker
	    w.onmessage = function (event) { // w.onmessage
	    	temp = temp - Number(event.data);
	    	$('#timers').text(String(temp.toFixed(2)) + "초");
	    	
	    	if(Number($('#timers').text().replace("초","")) <= 0) {
	    		//w.terminate();
 		    	//w = null;
	    		
	    		Wrong = Wrong + 1;
	    		Count = Count + 1;
	    		
	    		TotalSecs = TotalSecs + QSecs; // 항상 타입을 체크하자!!!!!
	    		if(Count < _Nums) {
 					$('#question').text("[" + String(Count + 1) + "] : " + Questions[Count]);
 		 			for(var i = 0; i < _SNums; i++) {
	 	 				$('#answer' + Number(i + 1)).text(Number(i + 1) + " : " + Selects[Count][i]);}

 		 			answer = Answers[Count];
 		 			MyAnswer = 0;
 	 			}
	 			else {
	 				w.terminate();
	 		    	w = null;
	 			}
	 			temp = QSecs;
	 			$('#timers').text(String(temp.toFixed(2)) + "초");
	 			//w = new Worker(getContextPath() + "/QUIZ/JS/timer.js");
	 			//timerStart = true;
	    	}
	    	
	 		if(Number(MyAnswer) > 0) {
	 			//w.terminate();
 		    	//w = null;
	 			
 				if(MyAnswer == Number(Answers[Count])) {
	 				Correct = Correct + 1;}
 				else {
 					Wrong = Wrong + 1;}
	 			Count = Count + 1;
	 			TotalSecs = TotalSecs + (QSecs - temp);
	 			if(Count < _Nums) {
		 			$('#question').text("[" + String(Count + 1) + "] : " + Questions[Count]);
		 			for(var i = 0; i < _SNums; i++) {
		 				$('#answer' + Number(i + 1)).text(Number(i + 1) + " : " + Selects[Count][i]);}
		 			answer = Answers[Count];
		 			MyAnswer = 0;
	 			}
	 			else {
	 				w.terminate();
	 		    	w = null;
	 			}
	 			temp = QSecs;
	 			$('#timers').text(String(temp.toFixed(2)) + "초");
	 			//w = new Worker(getContextPath() + "/QUIZ/JS/timer.js");
	 			//timerStart = true;
			}
	 		
	 		if(w == null) {
	 			send();
	 		//	timerStart = true;
 			//	w = new Worker(getContextPath() + "/QUIZ/JS/timer.js");
 				// alert('여긴?');
	 		}
	    }; // w.onmessage
	} else { // typeof(Worker)==="undefined"
		// Web workers are not supported by your browser
	   	alert('이 브라우저는 Web-Worker를 지원하지 않습니다. 최신 크롬 버전을 이용해주세요!');
	    location.href = 'main.jsp';
	}
}

$(document).ready(function() {
	Init();
	MakeQuiz();
	Play();
});
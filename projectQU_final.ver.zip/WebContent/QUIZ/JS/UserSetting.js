function OpenId() {
	$("#id_frame").show();
}

function OpenPw() {
	$("#pw_frame").show();
}

function OpenGrade() {
	$("#lv_frame").show();
}

function OpenExp() {
	$("#exp_frame").show();
}

function OpenPoint() {
	$("#point_frame").show();
}

function Init() {
	$("#id_num").val("");
	$("#id").val("");
	$("#id_dup").val("");
	$("#pw").val("");
	$("#change_pw").val("");
	$("#grade").val("");
	$("#exps").val("");
	$("#points").val("");
	$("#change_point").val("");
	
	$("#id_frame").hide();
	$("#pw_frame").hide();
	$("#lv_frame").hide();
	$("#exp_frame").hide();
	$("#point_frame").hide();
}

var send="send";

function DefaultSet() {
	
	$.ajax({
		type : "POST",
		url : 'setting_get.jsp',
		data : {send_ : send},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			$("#id_num").val(data.id_num);
			$("#id").val(data.id);
			$("#pw").val(data.pw);
			$("#grade").val(data.grade);
			$("#exps").val(data.exps);
			$("#points").val(data.points);
			
		},
		error : function(e) {
			alert('Error!');
			Init();
			return false;
		}
	});
}

function DupCheck() {
	if($("#change_id").val()=="")
	{
		alert("아이디를 입력해 주세요.");
		return false;
	}
	else if($("#change_id").val().length < 6)
	{
		alert("아이디는 6자 이상입니다.");
		return false;
	}
	else if($("#change_id").val().length > 12)
	{
		alert("아이디는 12자 이하입니다.");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "id_check.jsp",
		data : {userid : $("#change_id").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			alert(data.dup);
			$('#id_dup').val(data.dup);
			
			if($('#id_dup').val()=="N") {
				alert('사용 가능한 아이디입니다.');
				$("#change_id").prop('disabled', true);
				$('#IdDupBtn').prop("disabled", true);
			} else {
				alert('사용 불가능한 아이디입니다.');
				$("#change_id").val("");
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ChangeId() {
	if($("#id_dup").val() == "") {
		alert("아이디 중복을 확인해 주세요.");
		return false;
	}
	else if($("#id_dup").val() == "Y") {
		alert("사용 불가능한 아이디입니다.");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "setting_change_id.jsp",
		data : {userid : $("#change_id").val(), id_num : $("#id_num").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			if(data.result=="Y") {
				alert("변경완료! 자동 로그아웃 됩니다.");
				location.href = "logout.jsp";
			} else if(data.result=="N") {
				alert("변경실패! (포인트 부족)");
				$("#change_id").prop('disabled', false);
				$('#IdDupBtn').prop("disabled", false);
				$("#id_dup").val("");
			} else if(data.result=="F") {
				alert("변경실패! (오류)");
				$("#change_id").prop('disabled', false);
				$('#IdDupBtn').prop("disabled", false);
				$("#id_dup").val("");
			} else {}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ChangePw() {
	if($("#change_pw").val()=="")
	{
		alert("패스워드를 입력해 주세요.");
		return false;
	}
	else if($("#change_pw").val().length < 8)
	{
		alert("패스워드는 8자 이상입니다.");
		return false;
	}
	else if($("#change_pw").val().length > 12)
	{
		alert("패스워드는 12자 이하입니다.");
		return false;
	}
	else if($("#change_pw").val() != $("#check_pw").val()) {
		alert("패스워드를 다시 입력해 주세요.");
		return false;
	} else {}
	
	$.ajax({
		type : "POST",
		url : "setting_change_pw.jsp",
		data : {userpw : $("#change_pw").val(), id_num : $("#id_num").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			if(data.result=="Y") {
				alert("변경완료! 자동 로그아웃 됩니다.");
				location.href = "logout.jsp";
			} else if(data.result=="N") {
				alert("변경실패! (오류)");
			} else {}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function LvlUp() {
	$.ajax({
		type : "POST",
		url : "setting_level_up.jsp",
		data : {id_num : $("#id_num").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			if(data.result=="Y") {
				alert("레밸업!");
				Init(); DefaultSet();
			} else if(data.result=="N") {
				alert("레밸업 실패! (부족하거나, MAX[5]레밸에 도달하였음)");
			} else {}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});	
}

function ChangePoint() {
	if($("#change_point").val()=="")
	{
		alert("환산할 포인트를 입력해 주세요.");
		return false;
	}
	else if(Number($("#change_point").val()) < 0) {
		alert("0 이상의 포인트를 입력해 주세요.");
		$("#change_point").val("");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "setting_change_point.jsp",
		data : {id_num : $("#id_num").val(), change_point : $("#change_point").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			if(data.result=="Y") {
				alert("환산 (포인트 -> 경험치)");
				Init(); DefaultSet();
			} else if(data.result=="N") {
				alert("환산 실패! (포인트 부족)");
				$("#change_point").val("");
			} else {}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});	
}

function ChangeExp() {
	if($("#change_exp").val()=="")
	{
		alert("환산할 경험치를 입력해 주세요.");
		return false;
	}
	else if(Number($("#change_exp").val()) < 0) {
		alert("0 이상의 경험치를 입력해 주세요.");
		$("#change_exp").val("");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "setting_change_exp.jsp",
		data : {id_num : $("#id_num").val(), change_exp : $("#change_exp").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			if(data.result=="Y") {
				alert("환산 (경험치 -> 포인트)");
				Init(); DefaultSet();
			} else if(data.result=="N") {
				alert("환산 실패! (경험치 부족)");
				$("#change_exp").val("");
			} else {}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});	
}

function DeleteMe() {
	if($("#id_num").val() == "") {
		alert("고유 아이디 번호를 찾을 수 없습니다.");
		return false;
	}
	
	//alert("분기점 지남");
	if(confirm("정말로 삭제하시겠습니까?")) {
		$.ajax({
			type : "POST", 
			url : "user_manager_delete_user.jsp",
			data : {id_num : $("#id_num").val()},
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				if(data.result=="Y") {
					alert("유저 삭제 완료");
				}
				else { // result=="F
					alert("유저 삭제 실패");
				}
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
	} else {
		alert("삭제 취소");
	}
}

$(document).ready(function() {
	Init();
	
	DefaultSet();
});
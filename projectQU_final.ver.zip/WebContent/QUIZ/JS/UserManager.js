var temp_id_num;
var temp_logged_in;
var temp_grade;

var temp_id;
var temp_pw;
var temp_exps;
var temp_points;
var temp_banned_start_day;
var temp_banned_end_day;
//변경, 삭제를 위한 임시 변수(조회한 값들을 임시로 저장한다.)

function Init() { // 태그(요소) 값들 초기화
	$("#user_nums").text("");	
	$("#search_id").val("");
	$("#search_id_num").val("");
	$("#total_info").val("");
	
	$("#id_num_hidden").val("");
	$("#id_num").val("");
	$("#logged_in").val("");
	$("#grade").val("");
	
	$("#id").val("");
	$("#pw").val("");
	$("#exps").val("");
	$("#points").val("");
	$("#banned_start_day").val("");
	$("#banned_end_day").val("");
}

function ajaxGetUserNum() { // 유저 수 받아오기
	$.ajax({
		type : "POST",
		url : "user_manager_get_nums.jsp",
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.user_nums);
			$("#user_nums").text(data.user_nums);
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function ajaxGetUserById() { // 이름(아이디)으로 검색하기
	if($("#search_id").val() == "") {
		alert("검색할 아이디를 입력해 주세요!");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "user_manager_get_by_id.jsp",
		data : {id : $("#search_id").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data);
			$("#id_num_hidden").val(data.id_num);
			$("#id_num").val(data.id_num);
			$("#logged_in").val(data.logged_in);
			$("#grade").val(data.grade);
			
			$("#id").val(data.id);
			$("#pw").val(data.pw);
			$("#exps").val(data.exps);
			$("#points").val(data.points);
			$("#banned_start_day").val(data.banned_start_day);
			$("#banned_end_day").val(data.banned_end_day);
			
			temp_id_num = data.id_num;
			temp_logged_in = data.logged_in;
			temp_grade = data.grade;

			temp_id = data.id;
			temp_pw = data.pw;
			temp_exps = data.exps;
			temp_points = data.points;
			temp_banned_start_day = data.banned_start_day;
			temp_banned_end_day = data.banned_end_day;
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
	
}

function ajaxGetUserByNum() { // 번호(아이디)로 검색하기
	if($("#search_id_num").val() == "") {
		alert("검색할 번호를 입력해 주세요!");
		return false;
	}
	
	$.ajax({
		type : "POST",
		url : "user_manager_get_by_num.jsp",
		data : {id_num : $("#search_id_num").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data);
			$("#id_num_hidden").val(data.id_num);
			$("#id_num").val(data.id_num);
			$("#logged_in").val(data.logged_in);
			$("#grade").val(data.grade);
			
			$("#id").val(data.id);
			$("#pw").val(data.pw);
			$("#exps").val(data.exps);
			$("#points").val(data.points);
			$("#banned_start_day").val(data.banned_start_day);
			$("#banned_end_day").val(data.banned_end_day);
			
			temp_id_num = data.id_num;
			temp_logged_in = data.logged_in;
			temp_grade = data.grade;

			temp_id = data.id;
			temp_pw = data.pw;
			temp_exps = data.exps;
			temp_points = data.points;
			temp_banned_start_day = data.banned_start_day;
			temp_banned_end_day = data.banned_end_day;
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
	
}

function ajaxGetAllUser() {
	$.ajax({
		type : "POST",
		url : "user_manager_get_all_user.jsp",
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.user_nums);
			var temp_contents;
			var temp2;
			for(var i = 0; i < Object.keys(data).length; i++) {
				temp_contents = $("#total_info").val();
				// $("#total_info").val();
				temp2 = "id_num : " + String(eval("data.l" + String(i) + "[0].id_num")) + "\r\n";
				temp2 = temp2 + "id : " + String(eval("data.l" + String(i) + "[0].id")) + "\r\n";
				temp2 = temp2 + "pw : " + String(eval("data.l" + String(i) + "[0].pw")) + "\r\n";
				temp2 = temp2 + "logged_in : " + String(eval("data.l" + String(i) + "[0].logged_in")) + "\r\n";
				temp2 = temp2 + "grade : " + String(eval("data.l" + String(i) + "[0].grade")) + "\r\n";
				temp2 = temp2 + "exps : " + String(eval("data.l" + String(i) + "[0].exps")) + "\r\n";
				temp2 = temp2 + "points : " + String(eval("data.l" + String(i) + "[0].points")) + "\r\n";
				temp2 = temp2 + "banned_start_day : " + String(eval("data.l" + String(i) + "[0].banned_start_day")) + "\r\n";
				temp2 = temp2 + "banned_end_day : " + String(eval("data.l" + String(i) + "[0].banned_end_day")) + "\r\n\r\n";
				$("#total_info").val(temp_contents + temp2);
			}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function UpdateUser() {
	if($("#id_num_hidden").val() == "") {
		alert("변경할 아이디를 검색해 주세요.");
		return false;
	}
	
	if($("#id_num").val() == temp_id_num && 
			$("#logged_in").val() == temp_logged_in && 
			$("#grade").val() == temp_grade && 
			$("#id").val() == temp_id && 
			$("#pw").val() == temp_pw && 
			$("#exps").val() == temp_exps && 
			$("#points").val() == temp_points && 
			$("#banned_start_day").val() == temp_banned_start_day && 
			$("#banned_end_day").val() == temp_banned_end_day) {
		alert("변경 사항이 하나 이상은 있어야 합니다.");
		return false;
	}
	
	//alert("분기점 지남");
	$.ajax({
		type : "POST", 
		url : "user_manager_update_user.jsp",
		data : {id_num : $("#id_num_hidden").val(),
			num : $("#id_num").val(),
			logged_in : $("#logged_in").val(),
			id : $("#id").val(), pw : $("#pw").val(),
			grade : $("#grade").val(),
			exps : $("#exps").val(),
			points : $("#points").val(),
			banned_start_day : $("#banned_start_day").val(),
			banned_end_day : $("#banned_end_day").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			if(data.result=="Y") {
				alert("유저 변경 완료");
				Init();
				ajaxGetUserNum();
			}
			else { // result=="F
				alert("유저 변경 실패");
			}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function DeleteUser() {
	if($("#id_num_hidden").val() == "") {
		alert("삭제할 아이디를 검색해 주세요.");
		return false;
	}
	
	//alert("분기점 지남");
	if(confirm("정말로 삭제하시겠습니까?")) {
		$.ajax({
			type : "POST", 
			url : "user_manager_delete_user.jsp",
			data : {id_num : $("#id_num_hidden").val()},
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				if(data.result=="Y") {
					alert("유저 삭제 완료");
					Init();
					ajaxGetUserNum();
				}
				else { // result=="F
					alert("유저 삭제 실패");
				}
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
	} else {
		alert("삭제 취소");
	}
}

$(document).ready(function() { // 엔터키 반응
	$("#search_id").keydown(function(key) {
		if (key.keyCode == 13) {
			ajaxGetUserById();
		}
	});
	$("#search_id_num").keydown(function(key) {
		if (key.keyCode == 13) {
			ajaxGetUserByNum();
		}
	});
});

$(document).ready(function () { 
	Init();
	
	ajaxGetUserNum();
	setInterval(function ajaxGetUserNum() { // 1분 간격으로 인원수 받아옴
		$.ajax({
			type : "POST",
			url : "user_manager_get_nums.jsp",
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				// alert(data.user_nums);
				$("#user_nums").text(data.user_nums);
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
	}, 60000);
});
/**
 * 
 */
var myVar;

function Timer()
{
   postMessage(0.01);
}
                
//if (timerStart){
myVar=setInterval(function(){Timer()}, 10);
//   timerStart = false;
//}
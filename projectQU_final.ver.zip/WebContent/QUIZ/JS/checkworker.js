function getContextPath() { // 절대경로 구하기
    	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
    	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};

var data;

onmessage = function(e) {
	data = e.data;
	
    setInterval(function() {
    	var xhr = new XMLHttpRequest();

    	xhr.open('POST', getContextPath() + "/QUIZ/JSP/check_connection.jsp", true);
    	xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    	xhr.onload = function() {
    		if (xhr.status === 200 || xhr.status === 201) {
    			postMessage(xhr.response);
    			// postMessage("hello~~!");
    		} else {
    			postMessage("Error");
    		}
    	};

    	xhr.responseType = 'json';
    	xhr.send("id_num=" + data);
    }, 3000);
};
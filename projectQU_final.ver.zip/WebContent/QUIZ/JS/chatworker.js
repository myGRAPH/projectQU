var first = "Y"; // 입장 표시

function getContextPath() { // 절대경로 구하기
    	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
    	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
    };

setInterval(function() {
	var xhr_ = new XMLHttpRequest();

	xhr_.open('GET', getContextPath() + "/ChatQuiz?first=" + first, true);
	xhr_.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

	xhr_.onload = function() {
		  if (xhr_.status === 200) {
			  postMessage(xhr_.response);
		  } else {
			  postMessage("E");
		  }
	};

	xhr_.responseType = 'json';
	xhr_.send();
	first = "N";
}, 1000);

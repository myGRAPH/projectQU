/**
 * 
 */
function ajaxQuesAnsNum() {
	$.ajax({
		type : "POST",
		url : "default_data_num.jsp",
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var q_nums = String(data.q_nums);
			//alert(q_nums);
			var a_nums = String(data.a_nums);
			$('#q_nums').text(q_nums);
			$('#a_nums').text(a_nums);
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

$(document).ready(function () {
	ajaxQuesAnsNum();
	setInterval(function ajaxQuesAnsNum() {
		$.ajax({
			type : "POST",
			url : "default_data_num.jsp",
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				var q_nums = String(data.q_nums);
				var a_nums = String(data.a_nums);
				$('#q_nums').text(q_nums);
				$('#a_nums').text(a_nums);
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
	}, 60000);
});

function ajaxProblemCreate() {
	if($('#questions').val() == "") {
		alert("질문을 입력해 주세요!");
		return false;
	}
	
	if($('#answer').val() == "") {
		alert("정답을 입력해 주세요!");
		return false;
	}
	
	if($("#levels").val() == "") {
		alert("레밸을 입력해 주세요!");
		return false;
	}
	
	if($("#types").val() == "") {
		alert("타입(종류)을(를) 입력해 주세요!");
		return false;
	}
	
	var questions =  $('#questions').val();
	var answer = $('#answer').val();
	var levels = $('#levels').val();
	var types = $('#types').val();
	
//	alert(questions);
//	alert(answer);
//	alert(levels);
//	alert(types);
//	
//	for(var i in q_array) {
//		alert(q_array[i]);
//	}
	$.ajax({
		type : "POST",
		url : "default_data_input_ok.jsp",
		data : {questions_ : questions, answer_ : answer, levels_ : levels, types_ : types},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			var Result = String(data.result);
			// alert(Result);
			if(Result == "Y") {
				alert('문제 생성 성공!');
				$('#questions').val("");
				$('#answer').val("");
				$('#levels').val("0");
				$('#types').val("0");
			} else {
				alert('문제 생성 실패!');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
	ajaxQuesAnsNum();
}
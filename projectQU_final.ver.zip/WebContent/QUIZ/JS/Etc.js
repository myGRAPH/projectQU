function CheckDate(start_day, end_day) { // 해당 기간(날짜)에 들어가는 지 비교하는 함수
	var Start_day = new Date(Date.parse(start_day.replace('-','/','g')));
	var End_day =  new Date(Date.parse(end_day.replace('-','/','g')));
	var Today = new Date();
	
	if(start_day == "" || End_day == "") {
		return false;
	}
	if(Today > Start_day && Today < End_day) {
		return true;
	}
	else {
		return false;
	}
}

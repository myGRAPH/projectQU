function getContextPath() { // 절대경로 구하기
    	var hostIndex = location.href.indexOf( location.host ) + location.host.length;
    	return location.href.substring( hostIndex, location.href.indexOf('/', hostIndex + 1) );
};

var checkworker;

function checkWorker(id_num_) { // 접속 체크용 웹 워커 함수
    if(!!window.Worker){ //브라우저가 웹 워커를 지원하는지 검사한다    
      // alert(id_num);
    	
      if(checkworker) checkworker.terminate();      //워커가 이미 존재하면 종료시킨다                     
      checkworker = new Worker(getContextPath() + "/QUIZ/JS/checkworker.js");  //새로운 워커(객체)를 생성한다       
      
      checkworker.onmessage = function(event) { //워커로부터 전달되는 메시지를 받는다
      	var obj = event.data;
      	
      	// alert("값 : " + obj.result);
      	if(obj.result == "Y") {
      		// alert("접속중");
      	} else if(obj.result == "N")  {
      		// alert("다른 곳의 접속 시도");
      		stopcheckWorker();
      		location.href = "logout.jsp";
      	} else if(obj.result == "E") {
      		alert("Error!");
      	} else {}
      }
      
      // alert(id_num_);
      checkworker.postMessage(id_num_);                    
    }
    else{
      alert("현재 브라우저는 웹 워커를 지원하지 않습니다")
    }
}
  
 function stopcheckWorker() {
    if(checkworker) {
      alert("로그아웃 처리됩니다.");
      checkworker.terminate();
	}
  }

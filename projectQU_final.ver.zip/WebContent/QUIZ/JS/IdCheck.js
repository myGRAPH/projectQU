/**
 * 
 */
function ajaxIdCheck() {
	if(document.frm1.userid.value=="")
	{
		alert("아이디를 입력해 주세요.");
		document.frm1.userid.focus();
		return false;
	}
	else if(document.frm1.userid.value.length < 6)
	{
		alert("아이디는 6자 이상입니다.");
		document.frm1.userid.focus();
		return false;
	}
	else if(document.frm1.userid.value.length > 12)
	{
		alert("아이디는 12자 이하입니다.");
		document.frm1.userid.focus();
		return false;
	}
	
	var id_value = $('#userid').val();
	if(id_value=="") {
		return false;
	}
		$.ajax({
			type : "POST",
			url : "id_check.jsp",
			data : {userid : id_value},
			dataType : "json", // xml, json, html, text ..
			async : false,
			success : function(data) {
				// alert(data.dup);
				
				$('#id_duplicate').val(data.dup);
				
				if($('#id_duplicate').val()=="N") {
					alert('사용 가능한 아이디입니다.');
					$("#userid").prop('disabled', true);
					$('#Btn1').prop("disabled", true);
				} else {
					alert('사용 불가능한 아이디입니다.');
					return false;
				} 
			},
			error : function(e) {
				alert('Error!');
				return false;
			}
		});
}

//	}
//$(function() {
//	$('button#Btn1').on('click', function() {
//		alert('test');
//		var id_value = $('#userid').val();
//		if(id_value=="")
//			alert('공백');
//		
//		$.ajax({
//			type : "POST",
//			url : "id_check.jsp",
//			data : {"userid" : id_value},
//			datatype : "JSON", // xml, json, html, text ..
//			success : function(obj) {
//				var data = JSON.parse(obj);
//				$("#id_duplicate").html(data.Result);
//			},
//			error : function(e) {
//				alert('Error!');
//			}
//		});
//	});
//});
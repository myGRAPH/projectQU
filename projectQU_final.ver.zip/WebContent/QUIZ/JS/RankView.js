/**
 * 
 **/

var PageRecNums; // 한 페이지당 보이는 레코드 수
var Records; // 전체 레코드 수 (행 수)
var t_pages; // 전체 페이지 수
var c_page; // 현재 페이지 값

var rank; // rank 배열
var id; // id 배열
var c; // correct 배열
var t; // total_time 배열
var r_day; // rec_day 배열

function Init() {
	PageRecNums = 10; // 한 페이지당 10개
	Records = 0;
	t_pages = 0;
	c_page = 0;
	/*
	rank.length = 0; // 배열 자체 초기화
	id.length = 0;
	c.length = 0;
	t.length = 0;
	r_day.length = 0;
	*/
	for(var i = 0; i <= 9; i++) {
		$("#rank" + i).text("");
		$("#id" + i).text("");
		$("#c" + i).text("");
		$("#t" + i).text("");
		$("#rec" + i).text("");
	}
	
	$("#c_page").text("");
	$("#t_pages").text("");
	
	HideViewAll(); // div(프레임) 속성을 숨김
}

function HideViewRecords(x, y) {
	for(var i = x; i < y; i++) {
		$("#rank" + i).hide();
		$("#id" + i).hide();
		$("#c" + i).hide();
		$("#t" + i).hide();
		$("#rec" + i).hide();
	}
}

function HideViewAll() {
//	for(var i = 0; i < 10; i++) {
//		$("#rank" + i).hide();
//		$("#id" + i).hide();
//		$("#c" + i).hide();
//		$("#t" + i).hide();
//		$("#rec" + i).hide();
//	}
//	$("#prevBtn").hide();
//	$("#c_page").hide();
//	$("#t_pages").hide();
//	$("#nextBtn").hide();
	
	$("#frame").hide();
}

function Close() {
	HideViewAll();
}

function GoDefaultRank(e_num) {
	Init();
	
	$.ajax({
		type : "POST",
		url : "get_default_rank.jsp",
		data : {e_num_ : e_num},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			
			Records = Object.keys(data).length;
			if(Records == 0) {
				alert("해당 랭킹에 등록된 아이디가 없습니다.");
				return false;
			}
			
			t_pages = Math.ceil(Records / PageRecNums);
			// alert(t_pages);
			
			rank = new Array(Records);
			id = new Array(Records);
			c = new Array(Records);
			t = new Array(Records);
			r_day = new Array(Records);
			
			for(var i = 0; i < Records; i++) {
				rank[i] = String(eval("data.r" + String(i) + "[0].rank"));
				id[i] = String(eval("data.r" + String(i) + "[0].id"));
				c[i] = String(eval("data.r" + String(i) + "[0].correct"));
				t[i] = String(eval("data.r" + String(i) + "[0].total_secs"));
				r_day[i] = String(eval("data.r" + String(i) + "[0].rec_day"));
			}
			// alert(rank[0]);
			// alert(id[0]);
			// alert(c[0]);
			// alert(t[0]);
			// alert(r_day[0]);

			$("#prevBtn").show();
			$("#nextBtn").show();
			$("#c_page").text(c_page + 1);
			$("#t_pages").text(t_pages);
			PageView(c_page); // 0 페이지 (디폴트)
			$("#frame").show();
		},
		error : function(e) {
			alert('Error(Default_Rank)');
			return false;
		}
		});
}

function GoMultiRank(e_num) {
	Init();
	
	$.ajax({
		type : "POST",
		url : "get_multi_rank.jsp",
		data : {e_num_ : e_num},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			Records = Object.keys(data).length;
			if(Records == 0) {
				alert("해당 랭킹에 등록된 아이디가 없습니다.");
				return false;
			}
			
			t_pages = Math.ceil(Records / PageRecNums);
			
			rank = new Array(Records);
			id = new Array(Records);
			c = new Array(Records);
			t = new Array(Records);
			r_day = new Array(Records);
			
			for(var i = 0; i < Records; i++) {
				rank[i] = String(eval("data.r" + String(i) + "[0].rank"));
				id[i] = String(eval("data.r" + String(i) + "[0].id"));
				c[i] = String(eval("data.r" + String(i) + "[0].correct"));
				t[i] = String(eval("data.r" + String(i) + "[0].total_secs"));
				r_day[i] = String(eval("data.r" + String(i) + "[0].rec_day"));
			}
			// alert(rank[0]);
			// alert(id[0]);
			// alert(c[0]);
			// alert(t[0]);
			// alert(r_day[0]);

			$("#prevBtn").show();
			$("#nextBtn").show();
			$("#c_page").text(c_page + 1);
			$("#t_pages").text(t_pages);
			
			PageView(c_page); // 0 페이지 (디폴트)
			$("#frame").show();
		},
		error : function(e) {
			alert('Error(Default_Rank)');
			return false;
		}
		});
}

function PageView(p_num) {
	$("#c_page").text(p_num + 1);
	
	$("#c_page").show();
	$("#t_pages").show(); 

	for(var i = (p_num * PageRecNums); i < (p_num + 1) * PageRecNums; i++) {
		if(i >= Records) {
			HideViewRecords(i - (p_num * PageRecNums), 10);
			//$("#rank" + i).hide();
			//$("#id" + i).hide();
			//$("#c" + i).hide();
			//$("#t" + i).hide();
			//$("#rec" + i).hide();
			break;
		}
		j = i - (p_num * PageRecNums);
	
		$("#rank" + j).text(rank[i]);
		$("#id" + j).text(id[i]);
		$("#c" + j).text(c[i]);
		$("#t" + j).text(t[i]);
		$("#rec" + j).text(r_day[i]);
		
		$("#rank" + j).show();
		$("#id" + j).show();
		$("#c" + j).show();
		$("#t" + j).show();
		$("#rec" + j).show();
	}
}

function Next() {
	if(Records >= 1) {
		c_page = (c_page + 1) % t_pages;
		PageView(c_page);
	}
}

function Prev() {
	if(Records >= 1) {
		c_page = (c_page + t_pages - 1) % t_pages;
		PageView(c_page);
	}
}

$(document).ready(function() {
	Init();
	// HideViewRecords(0, 4); // Test
});
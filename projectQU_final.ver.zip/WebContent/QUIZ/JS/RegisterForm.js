/**
 * 
 */
/**
 * 
 */

	function valid_check()
	{
		if(document.frm1.userid.value=="")
		{
			alert("아이디를 입력해 주세요.");
			document.frm1.userid.focus();
			return false;
		}
		else if(document.frm1.userid.value.length < 6)
		{
			alert("아이디는 6자 이상입니다.");
			document.frm1.userid.focus();
			return false;
		}
		else if(document.frm1.userid.value.length > 12)
		{
			alert("아이디는 12자 이하입니다.");
			document.frm1.userid.focus();
			return false;
		}
		
		if(document.frm1.id_duplicate.value=="")
		{
			alert("아이디 중복 확인해주세요.");
			return false;
		}
		else if(document.frm1.id_duplicate.value=="Y")
		{
			alert("다른 아이디를 선택해주세요.");
			document.frm1.id_duplicate.value="";
			return false;
		}
		
		if(document.frm1.passwd.value=="")
		{
			alert("패스워드를 입력해 주세요.");
			document.frm1.passwd.focus();
			return false;
		}
		else if(document.frm1.passwd.value.length < 8)
		{
			alert("패스워드는 8자 이상입니다.");
			document.frm1.userid.focus();
			return false;
		}
		else if(document.frm1.passwd.value.length > 12)
		{
			alert("패스워드는 12자 이하입니다.");
			document.frm1.userid.focus();
			return false;
		}
		
		if(document.frm1.passwd.value != document.frm1.passwd2.value)
		{
			alert("패스워드를 다시 확인해 주세요.");
			document.frm1.passwd.focus();
			return false;
		}
		
		document.frm1.submit();
	}
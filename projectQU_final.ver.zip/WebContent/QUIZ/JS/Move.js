/**
 * 홈페이지 이동 (일반 이동 , 부모 - 자식 창 생성)
 **/

// 자식창 window 객체를 저장할 변수
var windowObj;

function openLogin(){
	// 새창에 대한 세팅(옵션)
	var settings ='toolbar=no, directories=no, status=no, menubar=no, scrollbars=auto, resizable=no, height=150,width=350, left=0, top=0';
	// 자식창을 열고 자식창의 window 객체를 windowObj 변수에 저장
	windowObj = window.open("login.jsp" ,"login_window" , settings);
}

function openLogout(){
	location.href = "logout.jsp";
}

function openRegister(){
	// 새창에 대한 세팅(옵션)
	var settings ='toolbar=no, directories=no, status=no, menubar=no, scrollbars=auto, resizable=no, height=530,width=450, left=0, top=0';
	// 자식창을 열고 자식창의 window 객체를 windowObj 변수에 저장
	windowObj = window.open("register.jsp" ,"register_window" , settings);
}

function openGameMode() {
	location.href = "game_menu.jsp";
}

function openPlaza() {
	location.href = "plaza.jsp";
}

function openSetting() {
	location.href = "setting.jsp";
}

function openAdmin(){
	location.href = "admin.jsp";
}

function openDefaultDataInput() {
	// 새창에 대한 세팅(옵션)
	var settings ='toolbar=no, directories=no, status=no, menubar=no, scrollbars=auto, resizable=no, height=400,width=520, left=0, top=0';
	// 자식창을 열고 자식창의 window 객체를 windowObj 변수에 저장
	windowObj = window.open("default_data_input.jsp" ,"default_data_input_window" , settings);
}

function openDefaultDataManager() {
	// 새창에 대한 세팅(옵션)
	var settings ='toolbar=no, directories=no, status=no, menubar=no, scrollbars=auto, resizable=no, height=400,width=520, left=0, top=0';
	// 자식창을 열고 자식창의 window 객체를 windowObj 변수에 저장
	windowObj = window.open("default_data_manager.jsp" ,"default_data_manager_window" , settings);
}

function openUserManager() {
	// 새창에 대한 세팅(옵션)
	var settings ='toolbar=no, directories=no, status=no, menubar=no, scrollbars=auto, resizable=no, height=520,width=520, left=0, top=0';
	// 자식창을 열고 자식창의 window 객체를 windowObj 변수에 저장
	windowObj = window.open("user_manager.jsp" ,"user_manager_window" , settings);
}

function returnToMain(){
	location.href = "main.jsp"
}
/**
 * 
 */
var PageRecNums; // 한 페이지당 보이는 레코드 수
var Records; // 전체 레코드 수 (행 수)
var t_pages; // 전체 페이지 수
var c_page; // 현재 페이지 값

var p; // p 배열 (글 번호)
var id_num; // id_num 배열
var id; // id 배열
var title; // title 배열
var contents; // contents 배열
var cnt; // cnt 배열 
var rec; // rec 배열

var PageRecNums_re;
var Records_re; 
var t_pages_re;
var c_page_re;

var re; // r 배열 (리플 번호)
var id_num_re;
var id_re;
var reply; // reply (댓글 내용) 배열
var rec_re;

function InitBoardList() { // Board 초기화
	PageRecNums = 10; // 한 페이지당 10개
	Records = 0;
	t_pages = 0;
	c_page = 0;
	
	for(var i = 9; i >= 0; i--) {
		$("#p" + i).text("");
		$("#id" + i).text("");
		$("#title" + i).text("");
		$("#cnt" + i).text("");
		$("#rec" + i).text("");
		$("#id_num" + i).val("");
		$("#contents" + i).val("");
	}
	
	$("#c_page").text("");
	$("#t_pages").text("");
	
	HideBoard(); // div(프레임) 속성을 숨김
}

function InitReplyList() { // Reply 초기화
	PageRecNums_re = 10;
	Records_re = 0; 
	t_pages_re = 0;
	c_page_re = 0;
	
	$("#contents_re").val("");
	
	for(var i = 9; i >= 0; i--) {
		$("#r" + i).text(""); 
		$("#id" + i + "_re").text(""); 
		$("#reply" + i).text(""); 
		$("#rec" + i + "_re").text(""); 
		$("#id_num" + i + "_re").val("");
		$("#DelReBtn" + i).hide();
	}
	
	$("#c_page_re").text("");
	$("#t_pages_re").text("");
	
	HideReply(); // div(프레임) 속성을 숨김
}

function InitWBoard() {
	$("#title_w").val("");
	$("#contents_w").val("");
}

function InitRBoard() {
	$("#p_num_r").text("");
	$("#id_r").text("");
	$("#title_r").val("");
	$("#contents_r").val("");
	$("#id_num_r").val("");
}

function HideBoardList(x, y) {
	for(var i = x; i >= y; i--) {
		$("#p" + i).hide();
		$("#id" + i).hide();
		$("#title" + i).hide();
		$("#cnt" + i).hide();
		$("#rec" + i).hide();
	}
}

function HideReplyList(x, y) {
	for(var i = x; i >= y; i--) {
		$("#r" + i).hide(); 
		$("#id" + i + "_re").hide(); 
		$("#reply" + i).hide(); 
		$("#rec" + i + "_re").hide();
		$("#DelReBtn" + i).hide();
	}
}

function HideBoard() {
//	for(var i = 9; i >= 0; i++) {
//		$("#p" + i).hide();
//		$("#id" + i).hide();
//		$("#title" + i).hide();
//		$("#cnt" + i).hide();
//		$("#rec" + i).hide();
//	}
//	$("#prevBtn").hide();
//	$("#c_page").hide();
//	$("#t_pages").hide();
//	$("#nextBtn").hide();
	
	$("#B_frame").hide();
}

function HideReply() {
//	for(var i = 9; i >= 0; i++) {
//		$("#p" + i).hide();
//		$("#id" + i).hide();
//		$("#title" + i).hide();
//		$("#cnt" + i).hide();
//		$("#rec" + i).hide();
//	}
//	$("#prev_reBtn").hide();
//	$("#c_page_re").hide();
//	$("#t_pages_re").hide();
//	$("#next_reBtn").hide();
	
	$("#Re_frame").hide();
}

function HideWBoard() {
	$("#W_frame").hide();
}

function OpenWBoard() {
	InitWBoard();
	$("#W_frame").show();
}

function WriteBoard() {
	if($("#title_w").val() == "") {
		alert("제목을 작성해 주세요.");
		return false;
	}
	// alert($("#contents_w").val());
	
	$.ajax({
		type : "POST",
		url : "write_board.jsp",
		data : {title_w_ : $("#title_w").val(), contents_w_ : $("#contents_w").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			
			if(data.result=="Y") {
				// alert('글쓰기 성공');
				HideWBoard(); GetBoardList();
			} else {
				alert('글쓰기 실패');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function WriteCancel() {
	HideWBoard();
}

function UpdateBoard() {
	$.ajax({
		type : "POST",
		url : "update_board.jsp",
		data : {p_ : $("#p_num_r").text(), id_num_ : $("#id_num_r").val(), title_ : $("#title_r").val(), contents_ : $("#contents_r").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			
			if(data.result=="Y") {
				// alert('글 수정 성공');
				HideRBoard(); GetBoardList();
			} else if(data.result=="N"){
				alert('작성자만 수정 가능합니다.');
				return false;
			} else { // data.result=="F"
				alert('글 수정 실패');
			}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function DeleteBoard() {
	$.ajax({
		type : "POST",
		url : "delete_board.jsp",
		data : {p_ : $("#p_num_r").text(), id_num_ : $("#id_num_r").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			
			if(data.result=="Y") {
				// alert('글 삭제 성공');
				HideRBoard(); GetBoardList();
			} else if(data.result=="N"){
				alert('작성자만 삭제 가능합니다.');
				return false;
			} else { // data.result=="F"
				alert('글 삭제 실패');
			}
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});	
}

function HideRBoard() {
	$("#R_frame").hide();
}

function HideAll() {
	HideBoard();
	HideWBoard();
	HideRBoard();
}

$(document).ready(function() { // span 태그 클릭을 받기 위한 함수
	$("#title9").on('click', function(){
		OpenRBoard(9);
	});
	$("#title8").on('click', function(){
		OpenRBoard(8);
	});
	$("#title7").on('click', function(){
		OpenRBoard(7);
	});
	$("#title6").on('click', function(){
		OpenRBoard(6);
	});
	$("#title5").on('click', function(){
		OpenRBoard(5);
	});
	$("#title4").on('click', function(){
		OpenRBoard(4);
	});
	$("#title3").on('click', function(){
		OpenRBoard(3);
	});
	$("#title2").on('click', function(){
		OpenRBoard(2);
	});
	$("#title1").on('click', function(){
		OpenRBoard(1);
	});
	$("#title0").on('click', function(){
		OpenRBoard(0);
	});
});

function OpenRBoard(num) { // 조회수 증가, 게시글 내용 표시, 댓글 내용 표시
	$.ajax({
		type : "POST",
		url : "set_board_cnt.jsp",
		data : {p_ : $("#p" + num).text()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			
			if(data.result=="Y") {
				// alert('조회수 증가');
			} else {
				// alert('조회수 증가 실패');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
	
	InitRBoard();
	
	$("#p_num_r").text($("#p" + num).text());
	$("#id_r").text($("#id" + num).text());
	$("#title_r").val($("#title" + num).text());
	$("#contents_r").val($("#contents" + num).val());
	$("#id_num_r").val($("#id_num" + num).val());
	
	$("#R_frame").show();
	// $("#Re_frame").show();
	
	GetReplyList();
	
}

function GetReplyList() {
	InitReplyList();
	$.ajax({
		type : "POST",
		url : "get_reply.jsp",
		data : {p_ : $("#p_num_r").text()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			Records_re = Object.keys(data).length;
			// alert("Records_re : " + Records_re);
			if(Records_re == 0) {
				t_pages_re = 0; // 이전/다음 버튼 방지하기
				c_page_re = 0;
				
				// 나머지 게시글들은 초기화로 인하여 안보임! (공간만 차지함)
				
				$("#prev_reBtn").show();
				$("#next_reBtn").show();
				$("#c_page_re").text("0");
				$("#t_pages_re").text("0");
				// ReplyView(c_page); // 0 페이지 (디폴트)
				$("#Re_frame").show();
				return false;
			}
			t_pages_re = Math.ceil(Records_re / PageRecNums_re);
			// alert("t_pages_re : " + t_pages_re);
			
			re = new Array(Records_re); // re 배열 (번호)
			id_num_re = new Array(Records_re); // id_num 배열
			id_re = new Array(Records_re); // id 배열
			reply = new Array(Records_re); // reply 배열 (내용)
			rec_re = new Array(Records_re); // rec 배열
			
			for(var i = 0; i < Records_re; i++) {
				re[i] = String(eval("data.r" + String(i) + "[0].r_num"));
				id_num_re[i] = String(eval("data.r" + String(i) + "[0].id_num"));
				id_re[i] = String(eval("data.r" + String(i) + "[0].id"));
				reply[i] = String(eval("data.r" + String(i) + "[0].contents"));
				rec_re[i] = String(eval("data.r" + String(i) + "[0].rec_day"));
			}
			
			
			$("#prev_reBtn").show();
			$("#next_reBtn").show();
			$("#c_page_re").text(c_page_re + 1);
			$("#t_pages_re").text(t_pages_re);
			ReplyListView(c_page_re); // 0 페이지 (디폴트)
			$("#Re_frame").show();
		},
		error : function(e) {
			alert('Error(Reply_View)');
			return false;
		}
		});

}

function ReplyListView(rp_num) {
$("#c_page_re").text(rp_num + 1);
	
	$("#c_page_re").show();
	$("#t_pages_re").show(); 
	
	for(var i = (Records_re - 1) - (rp_num * PageRecNums_re); i >= (Records_re) - ((rp_num + 1) * PageRecNums_re); i--) {
		if(i < 0) { // 
			HideReplyList(i + ((rp_num +1) * PageRecNums_re) - (Records_re), 0);
			break;
		}
		j = i + ((rp_num +1) * PageRecNums_re) - (Records_re);
		$("#r" + j).text(re[i]);
		$("#id" + j + "_re").text(id_re[i]);
		$("#id_num" + j + "_re").val(id_num_re[i]);
		$("#reply" + j).text(reply[i]);		
		$("#rec" + j + "_re").text(rec_re[i]);		
		
		$("#r" + j).show();
		$("#id" + j + "_re").show();
		$("#reply" + j).show();
		$("#rec" + j + "_re").show();
		$("#DelReBtn" + j).show();
	}
	
}

function SendReply() {
	if($("#contents_re").val() == "") {
		alert("리플을 작성해 주세요.");
		return false;
	}
	// alert($("#contents_re").val());
	// alert($("#p_num_r").text());
	$.ajax({
		type : "POST",
		url : "write_reply.jsp", // write_reply.jsp 작성하기!!!
		data : {p_ : $("#p_num_r").text(), reply_ : $("#contents_re").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			
			if(data.result=="Y") {
				// alert('리플 쓰기 성공');
				GetReplyList();
			} else {
				alert('리플 쓰기 실패');
				return false;
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});
}

function DeleteReply(num) {
	// alert($("#p_num_r").text());
	// alert($("#r" + num).text());
	// alert($("#id_num" + num + "_re").val());
	$.ajax({
		type : "POST",
		url : "delete_reply.jsp", // write_reply.jsp 작성하기!!!
		data : {p_ : $("#p_num_r").text(), r_ : $("#r" + num).text(), id_num_ : $("#id_num" + num + "_re").val()},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			// alert(data.result);
			
			if(data.result=="Y") {
				// alert('리플 삭제 성공');
				GetReplyList();
			} else if(data.result=="N"){
				alert('작성자만 삭제 가능합니다.');
				return false;
			} else { // data.result=="F"
				alert('리플 삭제 실패');
			} 
		},
		error : function(e) {
			alert('Error!');
			return false;
		}
	});	
}

function NextRe() {
	if(Records_re >= 1) {
		c_page_re = (c_page_re + 1) % t_pages_re;
		ReplyListView(c_page_re);
	}
}

function PrevRe() {
	if(Records_re >= 1) {
		c_page_re = (c_page_re + t_pages_re - 1) % t_pages_re;
		ReplyListView(c_page_re);
	}
}

function GetBoardList() {
	InitBoardList();
	
	$.ajax({
		type : "POST",
		url : "get_board.jsp",
		data : {temp : "Request From GetBoardList()"},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			
			Records = Object.keys(data).length;
			if(Records == 0) {
				t_pages = 0; // 이전/다음 버튼 방지하기
				c_page = 0;
				
				// 나머지 게시글들은 초기화로 인하여 안보임! (공간만 차지함)
				
				$("#prevBtn").show();
				$("#nextBtn").show();
				$("#c_page").text("0");
				$("#t_pages").text("0");
				// PageView(c_page); // 0 페이지 (디폴트)
				$("#B_frame").show();
				
				return false;
			}
			
			t_pages = Math.ceil(Records / PageRecNums);
			// alert(t_pages);
			
			p = new Array(Records); // p 배열 (글 번호)
			id_num = new Array(Records); // id_num 배열
			id = new Array(Records); // id 배열
			title = new Array(Records); // title 배열
			contents = new Array(Records); // contents 배열
			cnt = new Array(Records); // cnt 배열 
			rec = new Array(Records); // rec 배열
			
			for(var i = 0; i < Records; i++) {
				p[i] = String(eval("data.l" + String(i) + "[0].p_num"));
				id_num[i] = String(eval("data.l" + String(i) + "[0].id_num"));
				id[i] = String(eval("data.l" + String(i) + "[0].id"));
				title[i] = String(eval("data.l" + String(i) + "[0].title"));
				contents[i] = String(eval("data.l" + String(i) + "[0].contents"));
				cnt[i] = String(eval("data.l" + String(i) + "[0].cnt"));
				rec[i] = String(eval("data.l" + String(i) + "[0].rec_day"));
			}

			$("#prevBtn").show();
			$("#nextBtn").show();
			$("#c_page").text(c_page + 1);
			$("#t_pages").text(t_pages);
			BoardListView(c_page); // 0 페이지 (디폴트)
			$("#B_frame").show();
		},
		error : function(e) {
			alert('Error(Board_View)');
			return false;
		}
		});
}

function GetGMBoardList() {
	InitBoardList();
	
	$.ajax({
		type : "POST",
		url : "get_gm_board.jsp",
		data : {temp : "Request From GetGMBoardList()"},
		dataType : "json", // xml, json, html, text ..
		async : false,
		success : function(data) {
			
			Records = Object.keys(data).length;
			if(Records == 0) {
				t_pages = 0; // 이전/다음 버튼 방지하기
				c_page = 0;
				
				// 나머지 게시글들은 초기화로 인하여 안보임! (공간만 차지함)
				
				$("#prevBtn").show();
				$("#nextBtn").show();
				$("#c_page").text("0");
				$("#t_pages").text("0");
				// PageView(c_page); // 0 페이지 (디폴트)
				$("#B_frame").show();
				
				return false;
			}
			
			t_pages = Math.ceil(Records / PageRecNums);
			// alert(t_pages);
			
			p = new Array(Records); // p 배열 (글 번호)
			id_num = new Array(Records); // id_num 배열
			id = new Array(Records); // id 배열
			title = new Array(Records); // title 배열
			contents = new Array(Records); // contents 배열
			cnt = new Array(Records); // cnt 배열 
			rec = new Array(Records); // rec 배열
			
			for(var i = 0; i < Records; i++) {
				p[i] = String(eval("data.l" + String(i) + "[0].p_num"));
				id_num[i] = String(eval("data.l" + String(i) + "[0].id_num"));
				id[i] = String(eval("data.l" + String(i) + "[0].id"));
				title[i] = String(eval("data.l" + String(i) + "[0].title"));
				contents[i] = String(eval("data.l" + String(i) + "[0].contents"));
				cnt[i] = String(eval("data.l" + String(i) + "[0].cnt"));
				rec[i] = String(eval("data.l" + String(i) + "[0].rec_day"));
			}

			$("#prevBtn").show();
			$("#nextBtn").show();
			$("#c_page").text(c_page + 1);
			$("#t_pages").text(t_pages);
			BoardListView(c_page); // 0 페이지 (디폴트)
			$("#B_frame").show();
		},
		error : function(e) {
			alert('Error(GMBoard_View)');
			return false;
		}
		});
}

function BoardListView(p_num) {
	$("#c_page").text(p_num + 1);
	
	$("#c_page").show();
	$("#t_pages").show(); 

	for(var i = (Records - 1) - (p_num * PageRecNums); i >= (Records) - ((p_num + 1) * PageRecNums); i--) {
		if(i < 0) { // 
			HideBoardList(i + ((p_num +1) * PageRecNums) - (Records), 0);
			break;
		}
		j = i + ((p_num +1) * PageRecNums) - (Records);
		$("#p" + j).text(p[i]);
		$("#id" + j).text(id[i]);
		$("#title" + j).html("<u>" + title[i] + "</u>");
		$("#cnt" + j).text(cnt[i]);
		$("#rec" + j).text(rec[i]);
		$("#id_num" + j).val(id_num[i]);
		$("#contents" + j).val(contents[i]);
		
		$("#p" + j).show();
		$("#id" + j).show();
		$("#title" + j).show();
		$("#cnt" + j).show();
		$("#rec" + j).show();
	}
}

function Next() {
	if(Records >= 1) {
		c_page = (c_page + 1) % t_pages;
		BoardListView(c_page);
	}
}

function Prev() {
	if(Records >= 1) {
		c_page = (c_page + t_pages - 1) % t_pages;
		BoardListView(c_page);
	}
}

$(document).ready(function() {
	InitBoardList();
	InitReplyList();
	HideWBoard();
	HideRBoard();
	
	$("#contents_re").keydown(function(key) {
		if (key.keyCode == 13) {
			SendReply();
		}
	});
});